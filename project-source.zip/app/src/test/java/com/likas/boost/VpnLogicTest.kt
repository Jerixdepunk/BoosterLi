package com.likas.boost

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class VpnLogicTest {

    // --- WireGuardConfigParser ---

    private val sampleConf = """
        [Interface]
        PrivateKey = cHJpdmF0ZWtleWV4YW1wbGU=
        Address = 10.0.0.2/32
        DNS = 1.1.1.1

        [Peer]
        PublicKey = cHVibGlja2V5ZXhhbXBsZQ==
        Endpoint = jp.example.com:51820
        AllowedIPs = 0.0.0.0/0
    """.trimIndent()

    @Test
    fun parser_extractsAllFieldsCorrectly() {
        val profile = WireGuardConfigParser.parse(sampleConf, "Japan", "JP")
        assertEquals("jp.example.com", profile.host)
        assertEquals(51820, profile.port)
        assertEquals("10.0.0.2/32", profile.clientAddress)
        assertEquals("1.1.1.1", profile.dns)
    }

    @Test(expected = WireGuardConfigParser.ParseException::class)
    fun parser_throwsOnMissingPrivateKey() {
        val broken = "[Interface]\nAddress = 10.0.0.2/32\n[Peer]\nPublicKey = x\nEndpoint = a.com:51820"
        WireGuardConfigParser.parse(broken, "Test", "XX")
    }

    @Test
    fun profile_flagEmojiForJapan() {
        val profile = WireGuardConfigParser.parse(sampleConf, "Japan", "JP")
        assertEquals("🇯🇵", profile.flagEmoji())
    }

    // --- PathQualityMonitor ---

    @Test
    fun pathQuality_perfectConditionsScoreNearOne() {
        val monitor = PathQualityMonitor()
        val score = monitor.recordProbe(PathQualityMonitor.ProbeResult(rttMs = 20.0, expected = 10, received = 10))
        assertTrue("expected score > 0.9, got $score", score > 0.9)
    }

    @Test
    fun pathQuality_highLossDropsScoreBelowThreshold() {
        val monitor = PathQualityMonitor()
        repeat(3) {
            monitor.recordProbe(PathQualityMonitor.ProbeResult(rttMs = 300.0, expected = 10, received = 2))
        }
        assertTrue(monitor.shouldTriggerFailover())
    }

    @Test
    fun pathQuality_doesNotTriggerOnSingleBadSample() {
        val monitor = PathQualityMonitor()
        monitor.recordProbe(PathQualityMonitor.ProbeResult(rttMs = 20.0, expected = 10, received = 10))
        monitor.recordProbe(PathQualityMonitor.ProbeResult(rttMs = 20.0, expected = 10, received = 10))
        monitor.recordProbe(PathQualityMonitor.ProbeResult(rttMs = 500.0, expected = 10, received = 1))
        assertFalse(monitor.shouldTriggerFailover())
    }

    // --- ServerScorer ---

    @Test
    fun serverScorer_prefersLowerRttAndLoss() {
        val fast = ServerScorer.Candidate(
            WireGuardConfigParser.parse(sampleConf, "Japan", "JP"),
            historicalEwmaRttMs = 40.0, historicalLoss = 0.01
        )
        val slow = ServerScorer.Candidate(
            WireGuardConfigParser.parse(sampleConf, "Japan", "JP"),
            historicalEwmaRttMs = 250.0, historicalLoss = 0.2
        )
        val ranked = ServerScorer.rank(listOf(slow, fast))
        assertEquals(40.0, ranked.first().historicalEwmaRttMs)
    }

    @Test
    fun serverScorer_unknownServerGetsNeutralScore() {
        val known = ServerScorer.Candidate(
            WireGuardConfigParser.parse(sampleConf, "Japan", "JP"),
            historicalEwmaRttMs = 20.0, historicalLoss = 0.0
        )
        val unknown = ServerScorer.Candidate(
            WireGuardConfigParser.parse(sampleConf, "Japan", "JP"),
            historicalEwmaRttMs = null, historicalLoss = null
        )
        assertTrue(ServerScorer.score(known) > ServerScorer.score(unknown))
    }

    // --- MtuDiscovery ---

    @Test
    fun mtuDiscovery_findsMaxPassingSizeMinusOverhead() {
        // Simulate a path that fragments anything above 1400 bytes.
        val result = MtuDiscovery.discover(minMtu = 1280, maxMtu = 1420, wireGuardOverhead = 60) { size ->
            size <= 1400
        }
        assertEquals(1400 - 60, result)
    }

    @Test
    fun mtuDiscovery_neverGoesBelowSafeFloor() {
        // Simulate a path that fragments almost everything.
        val result = MtuDiscovery.discover(minMtu = 1280, maxMtu = 1420, wireGuardOverhead = 60) { size ->
            size <= 1281
        }
        assertTrue(result >= 1280 - 60)
    }
}
