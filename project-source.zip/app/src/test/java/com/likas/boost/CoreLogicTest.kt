package com.likas.boost

import org.junit.Assert.assertEquals
import org.junit.Test

class CoreLogicTest {

    // --- NetworkQualityMonitor.classify ---

    @Test
    fun quality_excellentForLowPingLowLoss() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 30.0, packetLossPct = 0.0, jitterMs = 5.0))
        assertEquals(NetworkQualityMonitor.Quality.EXCELLENT, q)
    }

    @Test
    fun quality_poorForHighPing() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 400.0, packetLossPct = 10.0, jitterMs = 90.0))
        assertEquals(NetworkQualityMonitor.Quality.POOR, q)
    }

    @Test
    fun quality_offlineForHighPacketLoss() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 50.0, packetLossPct = 60.0, jitterMs = 5.0))
        assertEquals(NetworkQualityMonitor.Quality.OFFLINE, q)
    }

    @Test
    fun quality_jitterComputedAsStandardDeviation() {
        val m = NetworkQualityMonitor()
        val jitter = m.computeJitter(listOf(50.0, 50.0, 50.0))
        assertEquals(0.0, jitter, 0.001)
    }

    // --- BatteryDataProfileManager.decide ---

    @Test
    fun profile_criticalWhenBatteryVeryLow() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(10, isMetered = false, signalQuality = NetworkQualityMonitor.Quality.EXCELLENT)
        )
        assertEquals(BatteryDataProfileManager.Profile.CRITICAL_SAVER, p)
    }

    @Test
    fun profile_dataSaverWhenMeteredAndWeakSignal() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(80, isMetered = true, signalQuality = NetworkQualityMonitor.Quality.POOR)
        )
        assertEquals(BatteryDataProfileManager.Profile.DATA_SAVER, p)
    }

    @Test
    fun profile_normalWhenHealthyBatteryAndGoodSignal() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(90, isMetered = false, signalQuality = NetworkQualityMonitor.Quality.GOOD)
        )
        assertEquals(BatteryDataProfileManager.Profile.NORMAL, p)
    }

    // --- GameSessionStateMachine.start/stop (restores prior DND state) ---

    @Test
    fun sessionMachine_restoresWhateverFilterWasActiveBefore() {
        val sm = GameSessionStateMachine()
        val applied = sm.start(GameSessionStateMachine.InterruptionFilter.NONE)
        assertEquals(GameSessionStateMachine.InterruptionFilter.PRIORITY, applied)
        val restored = sm.stop()
        assertEquals(GameSessionStateMachine.InterruptionFilter.NONE, restored)
    }

    @Test
    fun sessionMachine_isActiveReflectsState() {
        val sm = GameSessionStateMachine()
        assertEquals(false, sm.isActive())
        sm.start(GameSessionStateMachine.InterruptionFilter.ALL)
        assertEquals(true, sm.isActive())
        sm.stop()
        assertEquals(false, sm.isActive())
    }

    // --- ColorUtils (pure hex math for the dynamic theme system) ---

    @Test
    fun colorUtils_darkenReducesEachChannel() {
        // 0x7C = 124, 124 * 0.5 = 62 = 0x3E
        val result = ColorUtils.darken("#7C4DFF", 0.5f)
        assertEquals("#3E", result.substring(0, 3))
    }

    @Test
    fun colorUtils_lightenMovesTowardWhite() {
        val result = ColorUtils.lighten("#000000", 1.0f)
        assertEquals("#FFFFFF", result)
    }

    @Test
    fun colorUtils_contrastingTextIsBlackOnLightBackground() {
        assertEquals("#000000", ColorUtils.contrastingTextColor("#FFFFFF"))
    }

    @Test
    fun colorUtils_contrastingTextIsWhiteOnDarkBackground() {
        assertEquals("#FFFFFF", ColorUtils.contrastingTextColor("#111111"))
    }

    // --- RamPurgeDecision.shouldTrigger ---

    @Test
    fun ramPurge_triggersWhenUsageCrossesThresholdAndCooldownElapsed() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.95, lowMemory = false, msSinceLastTrigger = 70_000)
        assertEquals(true, result)
    }

    @Test
    fun ramPurge_doesNotTriggerDuringCooldown() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.95, lowMemory = false, msSinceLastTrigger = 5_000)
        assertEquals(false, result)
    }

    @Test
    fun ramPurge_doesNotTriggerBelowThresholdEvenWithoutCooldown() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.5, lowMemory = false, msSinceLastTrigger = 999_999)
        assertEquals(false, result)
    }

    @Test
    fun ramPurge_osLowMemoryFlagTriggersEvenBelowRatioThreshold() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.5, lowMemory = true, msSinceLastTrigger = 999_999)
        assertEquals(true, result)
    }

    // --- CpuUsageCalculator ---

    @Test
    fun cpuUsage_highLoadScenario() {
        val prev = CpuUsageCalculator.parse("cpu  100 0 100 800 0 0 0 0 0 0")!!
        val curr = CpuUsageCalculator.parse("cpu  200 0 200 850 0 0 0 0 0 0")!!
        val usage = CpuUsageCalculator.usagePercent(prev, curr)
        assertEquals(80, usage?.toInt())
    }

    @Test
    fun cpuUsage_returnsNullOnZeroDelta() {
        val sample = CpuUsageCalculator.parse("cpu  100 0 100 800 0 0 0 0 0 0")!!
        assertEquals(null, CpuUsageCalculator.usagePercent(sample, sample))
    }

    @Test
    fun cpuUsage_returnsNullForMalformedLine() {
        assertEquals(null, CpuUsageCalculator.parse("not a cpu line"))
    }

    // --- DndScheduleWindow (overnight wraparound) ---

    @Test
    fun scheduleWindow_normalDaytimeWindow() {
        assertEquals(true, DndScheduleWindow.isWithin(nowMinute = 600, startMinute = 480, endMinute = 720))
    }

    @Test
    fun scheduleWindow_overnightWindowLateNight() {
        assertEquals(true, DndScheduleWindow.isWithin(nowMinute = 1350, startMinute = 1320, endMinute = 120))
    }

    @Test
    fun scheduleWindow_overnightWindowExcludesMidday() {
        assertEquals(false, DndScheduleWindow.isWithin(nowMinute = 720, startMinute = 1320, endMinute = 120))
    }
}
