package com.likas.boost

import org.junit.Assert.assertEquals
import org.junit.Test

class CoreLogicTest {

    // --- DnsOptimizer.pickFastest ---

    @Test
    fun dns_picksLowestRttAmongReachable() {
        val opt = DnsOptimizer()
        val results = listOf(
            DnsOptimizer.DnsResult("A", "1.1.1.1", 40, true),
            DnsOptimizer.DnsResult("B", "8.8.8.8", 25, true),
            DnsOptimizer.DnsResult("C", "9.9.9.9", null, false)
        )
        assertEquals("B", opt.pickFastest(results)?.name)
    }

    @Test
    fun dns_returnsNullWhenNoneReachable() {
        val opt = DnsOptimizer()
        val results = listOf(
            DnsOptimizer.DnsResult("A", "1.1.1.1", null, false),
            DnsOptimizer.DnsResult("B", "8.8.8.8", null, false)
        )
        assertEquals(null, opt.pickFastest(results))
    }

    // --- NetworkQualityMonitor.classify ---

    @Test
    fun quality_excellentForLowPingLowLoss() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 30.0, packetLossPct = 0.0, jitterMs = 5.0))
        assertEquals(NetworkQualityMonitor.Quality.EXCELLENT, q)
    }

    @Test
    fun quality_poorForHighPing() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 400.0, packetLossPct = 10.0, jitterMs = 90.0))
        assertEquals(NetworkQualityMonitor.Quality.POOR, q)
    }

    @Test
    fun quality_offlineForHighPacketLoss() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 50.0, packetLossPct = 60.0, jitterMs = 5.0))
        assertEquals(NetworkQualityMonitor.Quality.OFFLINE, q)
    }

    @Test
    fun quality_jitterComputedAsStandardDeviation() {
        val m = NetworkQualityMonitor()
        val jitter = m.computeJitter(listOf(50.0, 50.0, 50.0))
        assertEquals(0.0, jitter, 0.001)
    }

    // --- BatteryDataProfileManager.decide ---

    @Test
    fun profile_criticalWhenBatteryVeryLow() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(10, isMetered = false, signalQuality = NetworkQualityMonitor.Quality.EXCELLENT)
        )
        assertEquals(BatteryDataProfileManager.Profile.CRITICAL_SAVER, p)
    }

    @Test
    fun profile_dataSaverWhenMeteredAndWeakSignal() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(80, isMetered = true, signalQuality = NetworkQualityMonitor.Quality.POOR)
        )
        assertEquals(BatteryDataProfileManager.Profile.DATA_SAVER, p)
    }

    @Test
    fun profile_normalWhenHealthyBatteryAndGoodSignal() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(90, isMetered = false, signalQuality = NetworkQualityMonitor.Quality.GOOD)
        )
        assertEquals(BatteryDataProfileManager.Profile.NORMAL, p)
    }

    // --- GfxProfileManager.Preset (pure enum values, no Android dependency) ---

    @Test
    fun gfxPreset_smoothPrioritizesFpsOverResolution() {
        val preset = GfxProfileManager.Preset.SMOOTH
        assertEquals(60, preset.fps)
        assertEquals(0.7f, preset.resolutionScale, 0.001f)
    }

    @Test
    fun gfxPreset_hdPrioritizesResolutionOverFps() {
        val preset = GfxProfileManager.Preset.HD
        assertEquals(1.0f, preset.resolutionScale, 0.001f)
        assertEquals(30, preset.fps)
    }

    // --- GameSessionStateMachine.start/stop (restores prior DND state) ---

    @Test
    fun sessionMachine_restoresWhateverFilterWasActiveBefore() {
        val sm = GameSessionStateMachine()
        val applied = sm.start(GameSessionStateMachine.InterruptionFilter.NONE)
        assertEquals(GameSessionStateMachine.InterruptionFilter.PRIORITY, applied)
        val restored = sm.stop()
        assertEquals(GameSessionStateMachine.InterruptionFilter.NONE, restored)
    }

    @Test
    fun sessionMachine_isActiveReflectsState() {
        val sm = GameSessionStateMachine()
        assertEquals(false, sm.isActive())
        sm.start(GameSessionStateMachine.InterruptionFilter.ALL)
        assertEquals(true, sm.isActive())
        sm.stop()
        assertEquals(false, sm.isActive())
    }
}
