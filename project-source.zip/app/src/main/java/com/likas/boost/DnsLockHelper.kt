package com.likas.boost

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

/**
 * "Ping Lock" — honestly scoped. A non-root Android app cannot force the
 * system to use a specific DNS server; only the user can, via Android's
 * own Private DNS setting (Settings > Network > Private DNS, Android 9+).
 * So instead of pretending to intercept traffic, this copies the
 * recommended DNS hostname and deep-links straight to that real settings
 * screen so the user can apply it in two taps.
 */
class DnsLockHelper {

    // Private DNS requires a hostname, not a bare IP, for the well-known public resolvers.
    private val privateDnsHostnames = mapOf(
        "Cloudflare" to "one.one.one.one",
        "Google" to "dns.google",
        "Quad9" to "dns.quad9.net"
    )

    fun hostnameFor(resolverName: String): String? = privateDnsHostnames[resolverName]

    fun copyToClipboard(context: Context, hostname: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Private DNS hostname", hostname))
    }

    fun openPrivateDnsSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Intent(Settings.ACTION_WIFI_SETTINGS) // Private DNS lives one tap deeper on most OEM skins from here
        } else {
            Intent(Settings.ACTION_SETTINGS)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
