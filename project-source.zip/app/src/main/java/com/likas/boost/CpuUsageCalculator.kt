package com.likas.boost

/**
 * Pure math for turning two raw /proc/stat "cpu" line samples into a usage
 * percentage. Separated from PerformanceMonitor (which does the actual file
 * I/O) so this stays unit-testable without Robolectric.
 */
object CpuUsageCalculator {

    data class CpuTimes(val idle: Long, val total: Long)

    /**
     * Parses a raw line like:
     *   "cpu  132453 231 55342 1245123 8123 0 421 0 0 0"
     * Fields after "cpu" are: user nice system idle iowait irq softirq steal
     */
    fun parse(line: String): CpuTimes? {
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.isEmpty() || parts[0] != "cpu") return null
        val nums = parts.drop(1).mapNotNull { it.toLongOrNull() }
        if (nums.size < 4) return null
        val idle = nums[3] + (nums.getOrElse(4) { 0L }) // idle + iowait
        val total = nums.sum()
        return CpuTimes(idle, total)
    }

    /** Returns 0.0–100.0, or null if the two samples don't allow a valid delta. */
    fun usagePercent(prev: CpuTimes, curr: CpuTimes): Double? {
        val totalDelta = curr.total - prev.total
        val idleDelta = curr.idle - prev.idle
        if (totalDelta <= 0) return null
        val usage = 1.0 - (idleDelta.toDouble() / totalDelta.toDouble())
        return (usage * 100.0).coerceIn(0.0, 100.0)
    }
}
