package com.likas.boost

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Schedules Game Mode to auto-enable/disable at set times using
 * AlarmManager.setAndAllowWhileIdle — an inexact alarm that doesn't
 * require the special SCHEDULE_EXACT_ALARM permission. Being honest: this
 * means firing can be a few minutes late under Doze, not to-the-second —
 * acceptable for "start winding down notifications around bedtime,"
 * not appropriate for anything requiring precise timing.
 */
class DndScheduleManager(private val context: Context) {

    companion object {
        const val ACTION_START = "com.likas.boost.DND_SCHEDULE_START"
        const val ACTION_STOP = "com.likas.boost.DND_SCHEDULE_STOP"
        private const val REQUEST_CODE_START = 501
        private const val REQUEST_CODE_STOP = 502
    }

    private val prefs = context.getSharedPreferences("dnd_schedule", Context.MODE_PRIVATE)

    data class Schedule(val startMinute: Int, val endMinute: Int, val enabled: Boolean)

    fun getSchedule(): Schedule = Schedule(
        startMinute = prefs.getInt("start", 22 * 60),
        endMinute = prefs.getInt("end", 6 * 60),
        enabled = prefs.getBoolean("enabled", false)
    )

    fun saveSchedule(schedule: Schedule) {
        prefs.edit()
            .putInt("start", schedule.startMinute)
            .putInt("end", schedule.endMinute)
            .putBoolean("enabled", schedule.enabled)
            .apply()
        if (schedule.enabled) scheduleAlarms(schedule) else cancelAlarms()
    }

    fun scheduleAlarms(schedule: Schedule) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTriggerMillisFor(schedule.startMinute), startPendingIntent())
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextTriggerMillisFor(schedule.endMinute), stopPendingIntent())
    }

    fun cancelAlarms() {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(startPendingIntent())
        am.cancel(stopPendingIntent())
    }

    /** Next occurrence of [minuteOfDay] — today if still ahead, otherwise tomorrow. */
    private fun nextTriggerMillisFor(minuteOfDay: Int): Long {
        val cal = Calendar.getInstance()
        val nowMillis = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
        cal.set(Calendar.MINUTE, minuteOfDay % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= nowMillis) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun startPendingIntent(): PendingIntent {
        val intent = Intent(context, DndScheduleReceiver::class.java).setAction(ACTION_START)
        return PendingIntent.getBroadcast(context, REQUEST_CODE_START, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun stopPendingIntent(): PendingIntent {
        val intent = Intent(context, DndScheduleReceiver::class.java).setAction(ACTION_STOP)
        return PendingIntent.getBroadcast(context, REQUEST_CODE_STOP, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
