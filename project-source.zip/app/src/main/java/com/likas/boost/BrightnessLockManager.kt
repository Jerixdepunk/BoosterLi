package com.likas.boost

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

/**
 * Locks screen brightness to a fixed level during gameplay (prevents
 * auto-brightness from dimming/brightening mid-match), using the real
 * Settings.System write API. This needs the special "Modify system
 * settings" permission — a separate, explicit grant screen Android shows
 * for exactly this kind of write, requested only when the user turns this
 * feature on (not bundled into the one-time onboarding, since most people
 * won't want it).
 */
class BrightnessLockManager(private val context: Context) {

    fun canWriteSettings(): Boolean = Settings.System.canWrite(context)

    fun requestWritePermission() {
        val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /** @param level 0..255 raw brightness value */
    fun lockBrightness(level: Int): Boolean {
        if (!canWriteSettings()) return false
        return try {
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, level.coerceIn(1, 255))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Restores auto-brightness when leaving Game Mode. */
    fun restoreAutoBrightness(): Boolean {
        if (!canWriteSettings()) return false
        return try {
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
            true
        } catch (e: Exception) {
            false
        }
    }
}
