package com.likas.boost

import android.content.Context
import org.json.JSONObject

/**
 * Stores booster settings per game package name, so switching games can
 * restore the right combo of settings automatically. Uses SharedPreferences
 * + JSON rather than pulling in Room, matching the "keep it lightweight"
 * goal — this data is small, simple key-value, and doesn't need SQL.
 */
class GameProfileManager(private val context: Context) {

    data class Profile(
        val packageName: String,
        val dndEnabled: Boolean = true,
        val batterySaverEnabled: Boolean = false,
        val brightnessLockLevel: Int = -1 // -1 = don't lock
    )

    private val prefs = context.getSharedPreferences("game_profiles", Context.MODE_PRIVATE)

    fun saveProfile(profile: Profile) {
        val json = JSONObject().apply {
            put("dndEnabled", profile.dndEnabled)
            put("batterySaverEnabled", profile.batterySaverEnabled)
            put("brightnessLockLevel", profile.brightnessLockLevel)
        }
        prefs.edit().putString(profile.packageName, json.toString()).apply()
    }

    fun getProfile(packageName: String): Profile {
        val raw = prefs.getString(packageName, null) ?: return Profile(packageName)
        return try {
            val json = JSONObject(raw)
            Profile(
                packageName = packageName,
                dndEnabled = json.optBoolean("dndEnabled", true),
                batterySaverEnabled = json.optBoolean("batterySaverEnabled", false),
                brightnessLockLevel = json.optInt("brightnessLockLevel", -1)
            )
        } catch (e: Exception) {
            Profile(packageName)
        }
    }

    fun deleteProfile(packageName: String) {
        prefs.edit().remove(packageName).apply()
    }

    fun allSavedPackageNames(): Set<String> = prefs.all.keys
}
