package com.likas.boost

import android.app.ActivityManager
import android.content.Context

/**
 * Best-effort background memory helper.
 *
 * IMPORTANT HONESTY NOTE: modern Android (5.0+) sandboxes every app from
 * every other app's memory. No non-rooted app — this one included — can
 * force-free another app's RAM the way old "task killer" apps claimed to.
 * What this class actually does, which is real and permitted:
 *   1. Clears this app's own cached files.
 *   2. Calls the public ActivityManager.killBackgroundProcesses() API,
 *      which asks the system to trim cached (not currently running)
 *      background processes for a given package. Since Android 8, the
 *      OS itself already aggressively manages this in the background,
 *      so the practical effect is usually small — but it's real and not
 *      fabricated.
 *   3. Reports current available/total memory via ActivityManager so the
 *      UI can show honest before/after numbers instead of a fake animation.
 */
class MemoryOptimizer(private val context: Context) {

    data class MemorySnapshot(val availMb: Long, val totalMb: Long, val lowMemory: Boolean)

    private val am: ActivityManager
        get() = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun snapshot(): MemorySnapshot {
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return MemorySnapshot(
            availMb = info.availMem / (1024 * 1024),
            totalMb = info.totalMem / (1024 * 1024),
            lowMemory = info.lowMemory
        )
    }

    /** Clears this app's own cache directory. Always safe, always real. */
    fun clearOwnCache(): Long {
        val dir = context.cacheDir ?: return 0
        var freedBytes = 0L
        dir.listFiles()?.forEach { f ->
            freedBytes += f.length()
            f.deleteRecursively()
        }
        return freedBytes / 1024
    }

    /**
     * Best-effort trim request for a list of other installed packages.
     * Requires the (normal, no-prompt) KILL_BACKGROUND_PROCESSES permission.
     * Effect is limited by design on modern Android — see class doc.
     */
    fun requestTrim(packageNames: List<String>) {
        packageNames.forEach { pkg ->
            try {
                am.killBackgroundProcesses(pkg)
            } catch (_: SecurityException) {
                // Ignore packages the system won't let us touch — expected and fine.
            }
        }
    }
}
