package com.likas.boost

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Wraps the official WireGuard-Android library (`com.wireguard.android:tunnel`)
 * to bring a real tunnel up/down, plus the health-monitoring/failover loop
 * built on the tested PathQualityMonitor.
 *
 * BUILD NOTE: this is the one class in the project whose exact API calls
 * depend on the WireGuard-Android library version resolved at build time —
 * I can't compile-test it in my own sandbox (no Android SDK there). If the
 * first real Gradle build flags an error here, it's almost always a small
 * method-signature mismatch against whatever library version Maven
 * resolves, not a logic bug — send me the error and I'll adjust the calls.
 * Every other file in this feature (parsing, scoring, MTU, storage) is
 * plain Kotlin/JSON and was independently verified.
 */
class VpnTunnelManager(private val context: Context) {

    private val backend by lazy { GoBackend(context) }
    private val quality = PathQualityMonitor()
    private var monitorJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private var activeProfile: VpnServerProfile? = null
    private var activeTunnel: SimpleTunnel? = null

    var onQualityUpdate: ((Double, Long?) -> Unit)? = null
    var onFailoverNeeded: ((VpnServerProfile) -> Unit)? = null

    private class SimpleTunnel(private val tunnelName: String) : Tunnel {
        var state: Tunnel.State = Tunnel.State.DOWN
        override fun getName(): String = tunnelName
        override fun onStateChange(newState: Tunnel.State) {
            state = newState
        }
    }

    fun buildConfig(profile: VpnServerProfile): Config {
        val iface = Interface.Builder()
            .parsePrivateKey(profile.clientPrivateKey)
            .parseAddresses(profile.clientAddress)
            .parseDnsServers(profile.dns)
            .build()

        val peer = Peer.Builder()
            .parsePublicKey(profile.serverPublicKey)
            .parseEndpoint("${profile.host}:${profile.port}")
            .parseAllowedIPs(profile.allowedIps)
            .build()

        return Config.Builder()
            .setInterface(iface)
            .addPeer(peer)
            .build()
    }

    fun connect(profile: VpnServerProfile, onResult: (success: Boolean, error: String?) -> Unit) {
        scope.launch {
            try {
                val config = buildConfig(profile)
                val tunnel = SimpleTunnel("likas_${profile.countryCode}")
                backend.setState(tunnel, Tunnel.State.UP, config)
                activeTunnel = tunnel
                activeProfile = profile
                startHealthMonitor(profile)
                onResult(true, null)
            } catch (e: Exception) {
                onResult(false, e.message ?: "Unknown connection error")
            }
        }
    }

    fun disconnect(onResult: (() -> Unit)? = null) {
        stopHealthMonitor()
        val tunnel = activeTunnel ?: run { onResult?.invoke(); return }
        scope.launch {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
            } catch (_: Exception) {
                // Already down or backend error on teardown — non-fatal for a disconnect request.
            }
            activeTunnel = null
            activeProfile = null
            onResult?.invoke()
        }
    }

    fun isConnected(): Boolean = activeTunnel?.state == Tunnel.State.UP

    /**
     * Real health probing: once the tunnel is up, our own app's traffic is
     * routed through it (VpnService captures the whole device by default),
     * so a TCP round-trip to the tunnel's configured DNS server measures
     * genuine end-to-end tunnel latency — the same proven TCP-timing
     * technique already used and tested in DnsOptimizer, just measured
     * through the tunnel instead of the raw connection. Probing the
     * WireGuard server's own UDP port directly wouldn't give a meaningful
     * result over TCP, so this deliberately measures something real
     * instead.
     */
    private fun startHealthMonitor(profile: VpnServerProfile) {
        quality.reset()
        monitorJob = scope.launch {
            while (true) {
                delay(2000)
                val rtt = probeRttMs(profile.dns, 53)
                val result = PathQualityMonitor.ProbeResult(
                    rttMs = rtt,
                    expected = 1,
                    received = if (rtt != null) 1 else 0
                )
                val score = quality.recordProbe(result)
                onQualityUpdate?.invoke(score, rtt?.toLong())

                VpnServerStore(context).recordPerformance(profile, quality.ewmaRttMs, quality.ewmaLoss)

                if (quality.shouldTriggerFailover()) {
                    onFailoverNeeded?.invoke(profile)
                }
            }
        }
    }

    private fun stopHealthMonitor() {
        monitorJob?.cancel()
        monitorJob = null
    }

    private fun probeRttMs(host: String, port: Int, timeoutMs: Int = 2000): Double? {
        return try {
            val start = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
            (System.nanoTime() - start) / 1_000_000.0
        } catch (_: Exception) {
            null
        }
    }
}
