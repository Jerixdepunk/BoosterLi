package com.likas.boost

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stores the servers the user has personally added (their own VPS, or a
 * config from a VPN provider they already pay for). LIKAS never ships with
 * any servers pre-loaded — there's nothing to connect to until the user
 * adds at least one. Uses org.json (built into Android, no extra
 * dependency) for simple local persistence.
 */
class VpnServerStore(private val context: Context) {

    private val prefs = context.getSharedPreferences("likas_vpn_servers", Context.MODE_PRIVATE)
    private val KEY = "servers_json"

    fun getAll(): List<VpnServerProfile> {
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val result = mutableListOf<VpnServerProfile>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result.add(
                VpnServerProfile(
                    countryName = o.getString("countryName"),
                    countryCode = o.getString("countryCode"),
                    host = o.getString("host"),
                    port = o.getInt("port"),
                    clientPrivateKey = o.getString("clientPrivateKey"),
                    clientAddress = o.getString("clientAddress"),
                    serverPublicKey = o.getString("serverPublicKey"),
                    dns = o.getString("dns"),
                    allowedIps = o.getString("allowedIps")
                )
            )
        }
        return result
    }

    fun add(profile: VpnServerProfile) {
        val current = getAll().toMutableList()
        current.add(profile)
        save(current)
    }

    fun remove(profile: VpnServerProfile) {
        val current = getAll().filterNot {
            it.host == profile.host && it.serverPublicKey == profile.serverPublicKey
        }
        save(current)
    }

    private fun save(list: List<VpnServerProfile>) {
        val arr = JSONArray()
        list.forEach { p ->
            val o = JSONObject()
            o.put("countryName", p.countryName)
            o.put("countryCode", p.countryCode)
            o.put("host", p.host)
            o.put("port", p.port)
            o.put("clientPrivateKey", p.clientPrivateKey)
            o.put("clientAddress", p.clientAddress)
            o.put("serverPublicKey", p.serverPublicKey)
            o.put("dns", p.dns)
            o.put("allowedIps", p.allowedIps)
            arr.put(o)
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    // --- Per-server historical performance, feeding ServerScorer ---

    fun getHistoricalRtt(profile: VpnServerProfile): Double? {
        val v = prefs.getFloat("rtt_${profile.host}", -1f)
        return if (v < 0) null else v.toDouble()
    }

    fun getHistoricalLoss(profile: VpnServerProfile): Double? {
        val v = prefs.getFloat("loss_${profile.host}", -1f)
        return if (v < 0) null else v.toDouble()
    }

    fun recordPerformance(profile: VpnServerProfile, ewmaRttMs: Double, loss: Double) {
        prefs.edit()
            .putFloat("rtt_${profile.host}", ewmaRttMs.toFloat())
            .putFloat("loss_${profile.host}", loss.toFloat())
            .apply()
    }
}
