package com.likas.boost

/**
 * Scores candidate servers to pick the best one for a country when the
 * user has configured more than one server for the same country.
 *
 * HONESTY NOTE vs. the original spec: the original formula includes a
 * "live server load" term fed by a control-plane that polls every server's
 * CPU/bandwidth every 10s. LIKAS has no such backend — there's no server
 * fleet to poll. So this version scores only on what the client can
 * actually measure itself: historical round-trip performance (from
 * PathQualityMonitor's EWMA) and packet loss. That's a real, honest signal;
 * "live load balancing across a global fleet" would require an actual
 * multi-server backend operation, not app code.
 */
object ServerScorer {

    data class Candidate(
        val profile: VpnServerProfile,
        val historicalEwmaRttMs: Double?, // null = never connected before
        val historicalLoss: Double?
    )

    private const val RTT_NORM_MS = 300.0

    fun score(candidate: Candidate): Double {
        // Unknown servers get a neutral middle score so they still get tried,
        // rather than being ranked last purely for lack of history.
        val rtt = candidate.historicalEwmaRttMs ?: (RTT_NORM_MS / 2)
        val loss = candidate.historicalLoss ?: 0.1

        val normRtt = (rtt / RTT_NORM_MS).coerceIn(0.0, 1.0)
        val perfScore = 0.7 * (1 - normRtt) + 0.3 * (1 - loss)
        return perfScore.coerceIn(0.0, 1.0)
    }

    /** Ranks candidates best-first. */
    fun rank(candidates: List<Candidate>): List<Candidate> =
        candidates.sortedByDescending { score(it) }
}
