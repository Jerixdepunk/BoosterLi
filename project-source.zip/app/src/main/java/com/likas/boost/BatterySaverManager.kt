package com.likas.boost

import android.content.Context
import android.provider.Settings

/**
 * "Battery Saver Mode" — honestly scoped. Reducing CPU frequency directly
 * isn't possible for a non-root third-party app; there's no public API for
 * it. What this actually does, all real and documented:
 *   1. Dims brightness via the same Settings.System write path as
 *      BrightnessLockManager (reuses its permission check).
 *   2. Shortens screen timeout via Settings.System.SCREEN_OFF_TIMEOUT.
 *   3. Asks the system to trim cache-heavy background apps via
 *      MemoryOptimizer, which reduces background CPU/battery use — the
 *      same real, limited mechanism documented in MemoryOptimizer.kt.
 */
class BatterySaverManager(private val context: Context) {

    private val brightnessManager = BrightnessLockManager(context)
    private val memoryOptimizer = MemoryOptimizer(context)

    private val cacheHeavyPackages = listOf(
        "com.android.chrome",
        "com.facebook.katana",
        "com.facebook.orca",
        "com.instagram.android",
        "com.google.android.youtube",
        "com.whatsapp"
    )

    fun canApply(): Boolean = brightnessManager.canWriteSettings()

    fun requestPermission() = brightnessManager.requestWritePermission()

    fun enable(dimBrightnessLevel: Int = 90, screenTimeoutMs: Int = 15_000): Boolean {
        if (!canApply()) return false
        return try {
            brightnessManager.lockBrightness(dimBrightnessLevel)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, screenTimeoutMs)
            memoryOptimizer.clearOwnCache()
            memoryOptimizer.requestTrim(cacheHeavyPackages)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun disable(restoreTimeoutMs: Int = 60_000): Boolean {
        if (!canApply()) return false
        return try {
            brightnessManager.restoreAutoBrightness()
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_OFF_TIMEOUT, restoreTimeoutMs)
            true
        } catch (e: Exception) {
            false
        }
    }
}
