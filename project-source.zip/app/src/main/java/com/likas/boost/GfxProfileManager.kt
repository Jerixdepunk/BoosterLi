package com.likas.boost

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/**
 * A "GFX Tool"-style config profile manager.
 *
 * HOW THIS ACTUALLY WORKS (and its real limits): some games read graphics
 * settings from a config file inside their own accessible data/config
 * folder. This class lets the user pick that folder via Android's Storage
 * Access Framework (a normal file picker — no special permission beyond
 * one-time folder consent) and writes a config file into it. It never
 * touches another app's memory or process.
 *
 * This only works for games that (a) store settings in an editable file
 * and (b) whose folder is exposed to the file picker. Not every game
 * supports this — that's a limitation of how each game is built, not
 * something any non-root app can work around.
 */
class GfxProfileManager(private val context: Context) {

    enum class Preset(val label: String, val resolutionScale: Float, val fps: Int, val quality: String) {
        SMOOTH("Smooth (best FPS)", 0.7f, 60, "low"),
        BALANCED("Balanced", 0.85f, 60, "medium"),
        HD("HD (best visuals)", 1.0f, 30, "high")
    }

    private val prefs = context.getSharedPreferences("gfx_profiles", Context.MODE_PRIVATE)

    fun saveSelectedPreset(gameLabel: String, preset: Preset) {
        prefs.edit().putString("preset_$gameLabel", preset.name).apply()
    }

    fun getSelectedPreset(gameLabel: String): Preset {
        val name = prefs.getString("preset_$gameLabel", Preset.BALANCED.name)
        return Preset.valueOf(name ?: Preset.BALANCED.name)
    }

    /**
     * Writes a simple key=value config file into the folder the user
     * selected via ACTION_OPEN_DOCUMENT_TREE. Returns true if the write
     * succeeded. The actual game must independently support reading a
     * file at that location — this call cannot verify that.
     */
    fun writeConfigToFolder(folderUri: Uri, fileName: String, preset: Preset): Boolean {
        return try {
            val dir = DocumentFile.fromTreeUri(context, folderUri) ?: return false
            val existing = dir.findFile(fileName)
            existing?.delete()
            val file = dir.createFile("text/plain", fileName) ?: return false
            context.contentResolver.openOutputStream(file.uri)?.use { out ->
                val content = buildString {
                    appendLine("resolution_scale=${preset.resolutionScale}")
                    appendLine("target_fps=${preset.fps}")
                    appendLine("graphics_quality=${preset.quality}")
                }
                out.write(content.toByteArray())
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
