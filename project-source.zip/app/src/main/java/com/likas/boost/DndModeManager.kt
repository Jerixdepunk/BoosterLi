package com.likas.boost

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * Wraps Android's public NotificationManager DND API to silence calls and
 * notifications during a game session, and reliably restores whatever the
 * user had set before, using GameSessionStateMachine for the pure logic.
 */
class DndModeManager(private val context: Context) {

    private val stateMachine = GameSessionStateMachine()

    fun hasDndAccess(): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.isNotificationPolicyAccessGranted
    }

    fun requestDndAccessIntent(): Intent =
        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)

    fun startGameMode() {
        if (!hasDndAccess()) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val current = toDomainFilter(nm.currentInterruptionFilter)
        val target = stateMachine.start(current)
        nm.setInterruptionFilter(toAndroidFilter(target))
    }

    fun stopGameMode() {
        if (!hasDndAccess()) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val restore = stateMachine.stop()
        nm.setInterruptionFilter(toAndroidFilter(restore))
    }

    fun isSessionActive(): Boolean = stateMachine.isActive()

    private fun toDomainFilter(f: Int): GameSessionStateMachine.InterruptionFilter = when (f) {
        NotificationManager.INTERRUPTION_FILTER_ALL -> GameSessionStateMachine.InterruptionFilter.ALL
        NotificationManager.INTERRUPTION_FILTER_PRIORITY -> GameSessionStateMachine.InterruptionFilter.PRIORITY
        NotificationManager.INTERRUPTION_FILTER_NONE -> GameSessionStateMachine.InterruptionFilter.NONE
        else -> GameSessionStateMachine.InterruptionFilter.UNKNOWN
    }

    private fun toAndroidFilter(f: GameSessionStateMachine.InterruptionFilter): Int = when (f) {
        GameSessionStateMachine.InterruptionFilter.ALL -> NotificationManager.INTERRUPTION_FILTER_ALL
        GameSessionStateMachine.InterruptionFilter.PRIORITY -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
        GameSessionStateMachine.InterruptionFilter.NONE -> NotificationManager.INTERRUPTION_FILTER_NONE
        GameSessionStateMachine.InterruptionFilter.UNKNOWN -> NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
