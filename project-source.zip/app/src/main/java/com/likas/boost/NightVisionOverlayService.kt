package com.likas.boost

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.WindowManager
import androidx.core.app.NotificationCompat

/**
 * A full-screen translucent overlay window that lifts shadow detail using
 * ordinary window alpha-compositing — the same mechanism blue-light/night
 * filter apps use (e.g. Twilight, CF.lumen): draw a semi-transparent,
 * warm-light layer and let Android's window compositor blend it against
 * whatever's underneath. It draws ON TOP of whatever's on screen; it never
 * reads game pixels, never touches game memory or files, and works
 * identically regardless of which app is in the foreground. That also
 * makes it a blunt instrument on purpose: it brightens/tints the whole
 * screen uniformly, not specific objects — there's no way (and no attempt
 * here) to selectively reveal only enemies or hidden objects, since a
 * third-party app can't see or sample another app's pixels without
 * MediaProjection, which this deliberately does not use.
 */
class NightVisionOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "likas_nightvision_channel"
        const val NOTIF_ID = 45
        const val EXTRA_INTENSITY = "intensity" // 0..100
    }

    private lateinit var windowManager: WindowManager
    private var filterView: NightVisionFilterView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        val intensity = intent?.getIntExtra(EXTRA_INTENSITY, 40) ?: 40
        if (filterView == null) addFilterView(intensity) else filterView?.setIntensity(intensity)
        return START_STICKY
    }

    private fun addFilterView(intensity: Int) {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        filterView = NightVisionFilterView(this).apply { setIntensity(intensity) }
        windowManager.addView(filterView, params)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "LIKAS Night Vision", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LIKAS")
            .setContentText("Night vision filter active")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        filterView?.let { windowManager.removeView(it) }
        filterView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

/** Draws a plain semi-transparent warm-light rectangle; the "lift" effect is pure window alpha compositing. */
private class NightVisionFilterView(context: android.content.Context) : android.view.View(context) {
    private val paint = android.graphics.Paint()
    private var alphaLevel = 60 // 0..255

    fun setIntensity(percent: Int) {
        alphaLevel = ((percent.coerceIn(0, 100)) / 100f * 90).toInt() // cap ~35% opacity max
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        paint.color = Color.argb(alphaLevel, 235, 232, 210)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }
}
