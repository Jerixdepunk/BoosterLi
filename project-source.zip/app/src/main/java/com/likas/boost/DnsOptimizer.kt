package com.likas.boost

import java.net.InetSocketAddress
import java.net.Socket

/**
 * Benchmarks a fixed set of well-known public DNS resolvers by timing a raw
 * TCP handshake to port 53 (works without any special permissions) and
 * recommends the fastest one that is actually reachable.
 *
 * This never touches any other app's traffic — it only measures round trip
 * time from THIS device to public, well-known resolvers.
 */
class DnsOptimizer {

    data class DnsResult(val name: String, val ip: String, val rttMs: Long?, val reachable: Boolean)

    private val candidates = listOf(
        "Cloudflare" to "1.1.1.1",
        "Google" to "8.8.8.8",
        "Quad9" to "9.9.9.9",
        "OpenDNS" to "208.67.222.222"
    )

    /** Times a TCP connect to port 53. Returns null RTT if unreachable within [timeoutMs]. */
    fun benchmarkOne(name: String, ip: String, timeoutMs: Int = 1500): DnsResult {
        return try {
            val start = System.nanoTime()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, 53), timeoutMs)
            }
            val elapsedMs = (System.nanoTime() - start) / 1_000_000
            DnsResult(name, ip, elapsedMs, true)
        } catch (e: Exception) {
            DnsResult(name, ip, null, false)
        }
    }

    fun benchmarkAll(timeoutMs: Int = 1500): List<DnsResult> =
        candidates.map { (name, ip) -> benchmarkOne(name, ip, timeoutMs) }

    /** Pure function (testable without network): pick lowest RTT among reachable results. */
    fun pickFastest(results: List<DnsResult>): DnsResult? =
        results.filter { it.reachable && it.rttMs != null }.minByOrNull { it.rttMs!! }

    fun recommend(timeoutMs: Int = 1500): DnsResult? = pickFastest(benchmarkAll(timeoutMs))
}
