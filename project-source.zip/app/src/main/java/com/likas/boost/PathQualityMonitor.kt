package com.likas.boost

/**
 * Real implementation of the "Path Quality Index" idea: tracks an
 * exponentially-weighted moving average of RTT and loss, plus jitter, and
 * produces a 0.0–1.0 quality score. Pure math — no network calls — so the
 * caller (the VPN service) feeds it real probe results and this class just
 * does the scoring/failover-trigger logic, which keeps it unit-testable.
 *
 * PQI = 0.4*(1 - normRTT) + 0.4*(1 - loss) + 0.2*(1 - normJitter)
 * Failover triggers when PQI stays below the threshold for N consecutive samples.
 */
class PathQualityMonitor(
    private val rttNormMs: Double = 300.0,   // RTT at/above this normalizes to 1.0 (worst)
    private val jitterNormMs: Double = 100.0,
    private val alpha: Double = 0.3,          // EWMA weight for RTT
    private val beta: Double = 0.3,           // EWMA weight for loss
    private val failoverThreshold: Double = 0.6,
    private val consecutiveBadSamplesToTrigger: Int = 3
) {
    var ewmaRttMs: Double = 0.0
        private set
    var ewmaLoss: Double = 0.0
        private set

    private val recentRtts = ArrayDeque<Double>()
    private val maxSamplesForJitter = 5
    private var consecutiveBadSamples = 0

    data class ProbeResult(val rttMs: Double?, val expected: Int, val received: Int)

    /** Feed one probe round's results. Returns the current PQI (0..1, 1 = perfect). */
    fun recordProbe(result: ProbeResult): Double {
        val lossThisRound = if (result.expected > 0)
            1.0 - (result.received.toDouble() / result.expected) else 0.0

        ewmaLoss = beta * lossThisRound + (1 - beta) * ewmaLoss

        if (result.rttMs != null) {
            ewmaRttMs = if (ewmaRttMs == 0.0) result.rttMs else alpha * result.rttMs + (1 - alpha) * ewmaRttMs
            recentRtts.addLast(result.rttMs)
            if (recentRtts.size > maxSamplesForJitter) recentRtts.removeFirst()
        }

        val score = currentScore()
        consecutiveBadSamples = if (score < failoverThreshold) consecutiveBadSamples + 1 else 0
        return score
    }

    fun jitterMs(): Double {
        if (recentRtts.size < 2) return 0.0
        val mean = recentRtts.average()
        val variance = recentRtts.sumOf { (it - mean) * (it - mean) } / recentRtts.size
        return Math.sqrt(variance)
    }

    fun currentScore(): Double {
        val normRtt = (ewmaRttMs / rttNormMs).coerceIn(0.0, 1.0)
        val normJitter = (jitterMs() / jitterNormMs).coerceIn(0.0, 1.0)
        val score = 0.4 * (1 - normRtt) + 0.4 * (1 - ewmaLoss) + 0.2 * (1 - normJitter)
        return score.coerceIn(0.0, 1.0)
    }

    fun shouldTriggerFailover(): Boolean = consecutiveBadSamples >= consecutiveBadSamplesToTrigger

    fun reset() {
        ewmaRttMs = 0.0
        ewmaLoss = 0.0
        recentRtts.clear()
        consecutiveBadSamples = 0
    }
}
