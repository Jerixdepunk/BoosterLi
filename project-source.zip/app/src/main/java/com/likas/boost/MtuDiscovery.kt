package com.likas.boost

/**
 * Binary-searches the largest packet size that gets through unfragmented,
 * matching the spec's MTU optimizer. The actual "send a DF-set probe
 * packet" is injected as a function so this stays pure and unit-testable —
 * the real VPN service supplies a probe that sends real packets, tests
 * supply a fake one.
 */
object MtuDiscovery {

    /**
     * @param canPassUnfragmented returns true if a packet of the given size
     *   reaches the far end without fragmentation.
     */
    fun discover(
        minMtu: Int = 1280,
        maxMtu: Int = 1420,
        wireGuardOverhead: Int = 60,
        canPassUnfragmented: (Int) -> Boolean
    ): Int {
        var low = minMtu
        var high = maxMtu
        var best = minMtu

        while (low <= high) {
            val mid = (low + high) / 2
            if (canPassUnfragmented(mid)) {
                best = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return (best - wireGuardOverhead).coerceAtLeast(1280 - wireGuardOverhead)
    }
}
