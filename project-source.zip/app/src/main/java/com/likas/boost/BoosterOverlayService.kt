package com.likas.boost

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

/**
 * Floating overlay bubble.
 *   - Tap: expand/collapse the small stats panel
 *   - Drag: move it anywhere on screen
 *   - Slider: resize the collapsed bubble between 40dp and 80dp
 *   - "Hide to edge": slides the bubble mostly off-screen so it doesn't
 *      block gameplay; tapping the sliver that remains visible brings it
 *      back, per the "hide it so it doesn't block the view, then reveal by
 *      tapping where it's hidden" requirement.
 */
class BoosterOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "likas_overlay_channel"
        const val NOTIF_ID = 43
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private var isHiddenToEdge = false
    private var isPanelExpanded = false
    private var screenWidthPx = 0

    private val statsHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private lateinit var statsRunnable: Runnable

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        screenWidthPx = dm.widthPixels
        addBubble()
        startStatsLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        return START_STICKY
    }

    private fun addBubble() {
        bubbleView = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 20
        params.y = 200

        windowManager.addView(bubbleView, params)
        setupDragAndTap(bubbleView!!)
        setupResizeSlider(bubbleView!!)
        setupHideButton(bubbleView!!)
    }

    private fun setupDragAndTap(view: View) {
        val circle = view.findViewById<View>(R.id.bubbleCircle)
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        circle.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX)
                    val dy = (event.rawY - touchY)
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    if (moved) {
                        if (isHiddenToEdge) unhideFromEdge()
                        params.x = initialX + dx.toInt()
                        params.y = initialY + dy.toInt()
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (isHiddenToEdge) unhideFromEdge() else togglePanel(view)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel(view: View) {
        val panel = view.findViewById<View>(R.id.bubblePanel)
        isPanelExpanded = !isPanelExpanded
        panel.visibility = if (isPanelExpanded) View.VISIBLE else View.GONE
    }

    private fun setupResizeSlider(view: View) {
        val slider = view.findViewById<SeekBar>(R.id.bubbleSizeSlider)
        val circle = view.findViewById<View>(R.id.bubbleCircle)
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val density = resources.displayMetrics.density
                val sizeDp = 40 + (progress / 100f) * 40f // 40dp..80dp
                val sizePx = (sizeDp * density).toInt()
                val lp = circle.layoutParams
                lp.width = sizePx
                lp.height = sizePx
                circle.layoutParams = lp
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    private fun setupHideButton(view: View) {
        view.findViewById<android.widget.Button>(R.id.btnHideBubble).setOnClickListener {
            hideToEdge(view)
        }
    }

    /** Slides the bubble mostly off the nearest screen edge, leaving a small tappable sliver. */
    private fun hideToEdge(view: View) {
        isHiddenToEdge = true
        isPanelExpanded = false
        view.findViewById<View>(R.id.bubblePanel).visibility = View.GONE

        val goingRight = params.x > screenWidthPx / 2
        params.x = if (goingRight) screenWidthPx - 16 else -40
        windowManager.updateViewLayout(view, params)
    }

    private fun unhideFromEdge() {
        isHiddenToEdge = false
        val goingBackFromRight = params.x > screenWidthPx / 2
        params.x = if (goingBackFromRight) screenWidthPx - 140 else 20
        bubbleView?.let { windowManager.updateViewLayout(it, params) }
    }

    private fun startStatsLoop() {
        statsRunnable = object : Runnable {
            override fun run() {
                updateStatsDisplay()
                statsHandler.postDelayed(this, 3000)
            }
        }
        statsHandler.post(statsRunnable)
    }

    private fun updateStatsDisplay() {
        val view = bubbleView ?: return
        val batteryPct = getBatteryPercent()
        val ramInfo = MemoryOptimizer(this).snapshot()

        view.findViewById<TextView>(R.id.statBattery).text = "Battery: $batteryPct%"
        view.findViewById<TextView>(R.id.statRam).text = "Free RAM: ${ramInfo.availMb} MB"
        // Ping is intentionally left to a background benchmark result set via updatePing(),
        // since a live per-second ping loop would itself consume the bandwidth it's measuring.
    }

    fun updatePing(rttMs: Long?) {
        bubbleView?.findViewById<TextView>(R.id.statPing)?.text =
            if (rttMs != null) "Ping: $rttMs ms" else "Ping: unreachable"
    }

    private fun getBatteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "LIKAS Overlay", NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LIKAS")
            .setContentText("Overlay active — tap the bubble for stats")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        statsHandler.removeCallbacksAndMessages(null)
        bubbleView?.let { windowManager.removeView(it) }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
