package com.likas.boost

import android.content.Context
import android.net.wifi.WifiManager

/**
 * "Wi-Fi Band Prioritization" — honestly scoped. Regular Android apps
 * cannot force the radio onto 5GHz/6GHz; band selection is handled by the
 * OS/driver and isn't exposed to third-party apps without root or Device
 * Owner privileges. What a normal app *can* do, and what this actually
 * does, is acquire a WifiManager.WifiLock at WIFI_MODE_FULL_HIGH_PERF,
 * which is a real, documented API that keeps the Wi-Fi radio out of its
 * power-save state during gameplay — the most common real cause of Wi-Fi
 * latency spikes on Android.
 */
class WifiPerformanceLock(context: Context) {

    private val appContext = context.applicationContext
    private var wifiLock: WifiManager.WifiLock? = null

    fun acquire(): Boolean {
        return try {
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val lock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LikasBoostPerf")
            lock.setReferenceCounted(false)
            lock.acquire()
            wifiLock = lock
            true
        } catch (e: Exception) {
            false
        }
    }

    fun release() {
        wifiLock?.let { if (it.isHeld) it.release() }
        wifiLock = null
    }

    fun isHeld(): Boolean = wifiLock?.isHeld ?: false
}
