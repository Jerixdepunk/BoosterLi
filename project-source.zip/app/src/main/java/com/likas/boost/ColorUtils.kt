package com.likas.boost

/**
 * Pure hex-color math with zero Android dependency. Kept separate from
 * ThemeManager (which touches SharedPreferences/Context) so this stays
 * runnable in plain JUnit tests without needing Robolectric.
 */
object ColorUtils {

    data class Rgb(val r: Int, val g: Int, val b: Int)

    fun parseHex(hex: String): Rgb {
        val clean = hex.removePrefix("#")
        val r = clean.substring(0, 2).toInt(16)
        val g = clean.substring(2, 4).toInt(16)
        val b = clean.substring(4, 6).toInt(16)
        return Rgb(r, g, b)
    }

    fun toHex(rgb: Rgb): String =
        "#%02X%02X%02X".format(rgb.r.coerceIn(0, 255), rgb.g.coerceIn(0, 255), rgb.b.coerceIn(0, 255))

    /** Relative luminance (0.0 dark – 1.0 light), standard perceptual weighting. */
    fun luminance(hex: String): Double {
        val (r, g, b) = parseHex(hex)
        return (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
    }

    /** Returns black or white text hex, whichever is readable against [backgroundHex]. */
    fun contrastingTextColor(backgroundHex: String): String =
        if (luminance(backgroundHex) > 0.6) "#000000" else "#FFFFFF"

    /** Multiplies each channel by [factor] (0..1) to darken, e.g. for status bar tint. */
    fun darken(hex: String, factor: Float): String {
        val f = factor.coerceIn(0f, 1f)
        val (r, g, b) = parseHex(hex)
        return toHex(Rgb((r * f).toInt(), (g * f).toInt(), (b * f).toInt()))
    }

    /** Blends [hex] toward white by [factor] (0..1) — used for pressed/hover states. */
    fun lighten(hex: String, factor: Float): String {
        val f = factor.coerceIn(0f, 1f)
        val (r, g, b) = parseHex(hex)
        return toHex(Rgb((r + (255 - r) * f).toInt(), (g + (255 - g) * f).toInt(), (b + (255 - b) * f).toInt()))
    }
}
