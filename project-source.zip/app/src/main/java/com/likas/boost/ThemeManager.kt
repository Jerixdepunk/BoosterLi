package com.likas.boost

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/**
 * Stores the user's chosen accent color and applies it consistently across
 * every screen: status bar, primary/secondary buttons, switches, and the
 * settings color-swatch grid. Simple SharedPreferences-backed approach —
 * no theming library needed, keeps the app lightweight.
 *
 * Color math (darken/lighten/contrast) lives in ColorUtils so it stays
 * unit-testable without Robolectric — this object just wires that math up
 * to real Android views.
 */
object ThemeManager {

    private const val PREFS = "likas_boost_prefs"
    private const val KEY_ACCENT = "accent_color"
    private const val KEY_ONBOARDING = "onboarding_complete"

    val presetColors = listOf(
        "#7C4DFF" to "Violet",
        "#2979FF" to "Electric Blue",
        "#00E676" to "Neon Green",
        "#FF3D3D" to "Crimson Red",
        "#FF9100" to "Sunset Orange",
        "#FFFFFF" to "Stellar White"
    )

    fun getAccentColorHex(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCENT, "#7C4DFF") ?: "#7C4DFF"
    }

    fun getAccentColor(context: Context): Int {
        return try {
            Color.parseColor(getAccentColorHex(context))
        } catch (e: Exception) {
            Color.parseColor("#7C4DFF")
        }
    }

    fun setAccentColor(context: Context, hex: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ACCENT, hex).apply()
    }

    fun isOnboardingComplete(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ONBOARDING, false)
    }

    fun setOnboardingComplete(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ONBOARDING, true).apply()
    }

    // --- Applied theming ---

    /** Tints the status bar a darkened shade of the accent so it doesn't clash with content. */
    fun applyStatusBar(activity: Activity) {
        val hex = getAccentColorHex(activity)
        val darkened = ColorUtils.darken(hex, 0.35f)
        activity.window.statusBarColor = Color.parseColor(darkened)
    }

    /** Filled "primary action" button: solid accent background, auto black/white text for contrast. */
    fun styleButtonPrimary(button: android.widget.Button, context: Context) {
        val hex = getAccentColorHex(context)
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16 * context.resources.displayMetrics.density
            setColor(Color.parseColor(hex))
        }
        button.background = bg
        button.setTextColor(Color.parseColor(ColorUtils.contrastingTextColor(hex)))
        button.elevation = 6 * context.resources.displayMetrics.density
    }

    /** Outline "secondary action" button: transparent fill, accent-colored border and text. */
    fun styleButtonSecondary(button: android.widget.Button, context: Context) {
        val hex = getAccentColorHex(context)
        val density = context.resources.displayMetrics.density
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 16 * density
            setColor(Color.TRANSPARENT)
            setStroke((1.5f * density).toInt(), Color.parseColor(hex))
        }
        button.background = bg
        button.setTextColor(Color.parseColor(hex))
        button.elevation = 0f
    }

    /** Tints a standard Switch's thumb/track to the accent color when checked. */
    fun styleSwitch(switchView: android.widget.Switch, context: Context) {
        val accent = getAccentColor(context)
        val states = arrayOf(
            intArrayOf(android.R.attr.state_checked),
            intArrayOf(-android.R.attr.state_checked)
        )
        val accentTrackAlpha40 = (0x66 shl 24) or (accent and 0x00FFFFFF)
        val thumbColors = intArrayOf(accent, Color.parseColor("#9E9E9E"))
        val trackColors = intArrayOf(accentTrackAlpha40, Color.parseColor("#33FFFFFF"))
        switchView.thumbTintList = android.content.res.ColorStateList(states, thumbColors)
        switchView.trackTintList = android.content.res.ColorStateList(states, trackColors)
    }

    /** Applies an accent-tinted glow ring behind the currently selected color swatch. */
    fun buildSwatchSelectionRing(context: Context, hex: String): GradientDrawable {
        val density = context.resources.displayMetrics.density
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setStroke((2.5f * density).toInt(), Color.parseColor(hex))
            setColor(Color.TRANSPARENT)
        }
    }
}
