package com.likas.boost

import android.content.Context
import android.graphics.Color

/**
 * Stores the user's chosen accent color and provides it to activities at
 * runtime to tint buttons/highlights. Simple SharedPreferences-backed
 * approach — no theming library needed, keeps the app lightweight.
 */
object ThemeManager {

    private const val PREFS = "likas_boost_prefs"
    private const val KEY_ACCENT = "accent_color"
    private const val KEY_ONBOARDING = "onboarding_complete"

    val presetColors = listOf(
        "#7C4DFF" to "Violet",
        "#2979FF" to "Electric Blue",
        "#00E676" to "Neon Green",
        "#FF3D3D" to "Crimson Red",
        "#FF9100" to "Sunset Orange",
        "#FFFFFF" to "Stellar White"
    )

    fun getAccentColorHex(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCENT, "#7C4DFF") ?: "#7C4DFF"
    }

    fun getAccentColor(context: Context): Int {
        return try {
            Color.parseColor(getAccentColorHex(context))
        } catch (e: Exception) {
            Color.parseColor("#7C4DFF")
        }
    }

    fun setAccentColor(context: Context, hex: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ACCENT, hex).apply()
    }

    fun isOnboardingComplete(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_ONBOARDING, false)
    }

    fun setOnboardingComplete(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ONBOARDING, true).apply()
    }
}
