package com.likas.boost

/**
 * Pure state machine for a "Game Mode" session: remembers what the DND
 * filter was BEFORE the user started a session, so it can be restored
 * exactly when the session ends — never leaves the user's phone silenced
 * after they're done playing. No Android dependency, fully unit-testable.
 */
class GameSessionStateMachine {

    enum class InterruptionFilter { ALL, PRIORITY, NONE, UNKNOWN }

    data class SessionState(
        val active: Boolean,
        val filterBeforeSession: InterruptionFilter?
    )

    private var state = SessionState(active = false, filterBeforeSession = null)

    /** Call when the user taps "Start Game Mode". Returns the filter to now apply. */
    fun start(currentFilter: InterruptionFilter): InterruptionFilter {
        state = SessionState(active = true, filterBeforeSession = currentFilter)
        return InterruptionFilter.PRIORITY
    }

    /** Call when the user taps "Stop Game Mode" or the app is closing. Returns filter to restore. */
    fun stop(): InterruptionFilter {
        val restore = state.filterBeforeSession ?: InterruptionFilter.ALL
        state = SessionState(active = false, filterBeforeSession = null)
        return restore
    }

    fun isActive(): Boolean = state.active
}
