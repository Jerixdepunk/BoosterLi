package com.likas.boost

/**
 * Parses a standard WireGuard `.conf` file (the format every WireGuard
 * server generates for a client, and what most VPN providers hand out) into
 * a VpnServerProfile. Pure string parsing — no Android/network dependency —
 * so it's fully unit-testable.
 *
 * Expected format:
 *   [Interface]
 *   PrivateKey = <client private key>
 *   Address = 10.0.0.2/32
 *   DNS = 1.1.1.1
 *
 *   [Peer]
 *   PublicKey = <server public key>
 *   Endpoint = vpn.example.com:51820
 *   AllowedIPs = 0.0.0.0/0
 */
object WireGuardConfigParser {

    class ParseException(message: String) : Exception(message)

    fun parse(confText: String, countryName: String, countryCode: String): VpnServerProfile {
        val values = mutableMapOf<String, String>()
        confText.lines().forEach { rawLine ->
            val line = rawLine.substringBefore('#').trim()
            if (line.isEmpty() || line.startsWith("[")) return@forEach
            val parts = line.split("=", limit = 2)
            if (parts.size == 2) {
                values[parts[0].trim().lowercase()] = parts[1].trim()
            }
        }

        val privateKey = values["privatekey"] ?: throw ParseException("Missing PrivateKey under [Interface]")
        val address = values["address"] ?: throw ParseException("Missing Address under [Interface]")
        val dns = values["dns"] ?: "1.1.1.1"
        val publicKey = values["publickey"] ?: throw ParseException("Missing PublicKey under [Peer]")
        val endpoint = values["endpoint"] ?: throw ParseException("Missing Endpoint under [Peer]")
        val allowedIps = values["allowedips"] ?: "0.0.0.0/0"

        val endpointParts = endpoint.split(":")
        if (endpointParts.size != 2) throw ParseException("Endpoint must be host:port, got '$endpoint'")
        val host = endpointParts[0]
        val port = endpointParts[1].toIntOrNull() ?: throw ParseException("Invalid port in Endpoint '$endpoint'")

        return VpnServerProfile(
            countryName = countryName,
            countryCode = countryCode,
            host = host,
            port = port,
            clientPrivateKey = privateKey,
            clientAddress = address,
            serverPublicKey = publicKey,
            dns = dns,
            allowedIps = allowedIps
        )
    }
}
