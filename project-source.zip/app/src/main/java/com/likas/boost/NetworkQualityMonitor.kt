package com.likas.boost

/**
 * Pure, testable logic that classifies connection quality from ping samples.
 * Used to drive both the floating overlay readout and the battery/data
 * profile switcher.
 */
class NetworkQualityMonitor {

    enum class Quality { EXCELLENT, GOOD, FAIR, POOR, OFFLINE }

    data class Sample(val avgPingMs: Double, val packetLossPct: Double, val jitterMs: Double)

    fun classify(sample: Sample): Quality {
        if (sample.packetLossPct >= 50.0) return Quality.OFFLINE
        return when {
            sample.avgPingMs <= 60 && sample.packetLossPct <= 1 && sample.jitterMs <= 15 -> Quality.EXCELLENT
            sample.avgPingMs <= 120 && sample.packetLossPct <= 3 && sample.jitterMs <= 30 -> Quality.GOOD
            sample.avgPingMs <= 250 && sample.packetLossPct <= 8 && sample.jitterMs <= 60 -> Quality.FAIR
            else -> Quality.POOR
        }
    }

    /** Standard deviation-based jitter from a list of individual ping times. */
    fun computeJitter(pings: List<Double>): Double {
        if (pings.size < 2) return 0.0
        val mean = pings.average()
        val variance = pings.sumOf { (it - mean) * (it - mean) } / pings.size
        return Math.sqrt(variance)
    }
}
