package com.likas.boost

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity

/**
 * Intro screen: star logo scales/fades in, "LIKAS" title follows, footer
 * credit fades in last, with a short synthesized "power-up" whoosh
 * (res/raw/intro_whoosh.wav — an originally generated tone, not a
 * copyrighted sample, so it's safe to ship). Swap that file for your own
 * .wav/.mp3 of the same filename any time to change the sound.
 */
class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        val star = findViewById<android.widget.ImageView>(R.id.splashStar)
        val title = findViewById<android.widget.TextView>(R.id.splashTitle)
        val footer = findViewById<android.widget.TextView>(R.id.splashFooter)

        star.scaleX = 0.4f
        star.scaleY = 0.4f

        playPowerUpTone()

        val starIn = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(star, "alpha", 0f, 1f).setDuration(500),
                ObjectAnimator.ofFloat(star, "scaleX", 0.4f, 1f).setDuration(650),
                ObjectAnimator.ofFloat(star, "scaleY", 0.4f, 1f).setDuration(650)
            )
            interpolator = OvershootInterpolator(1.6f)
        }

        val titleIn = ObjectAnimator.ofFloat(title, "alpha", 0f, 1f).apply {
            duration = 450
            startDelay = 550
            interpolator = AccelerateDecelerateInterpolator()
        }

        val footerIn = ObjectAnimator.ofFloat(footer, "alpha", 0f, 1f).apply {
            duration = 400
            startDelay = 1050
        }

        AnimatorSet().apply {
            playTogether(starIn, titleIn, footerIn)
            start()
        }

        handler.postDelayed({ proceed() }, 2400)
    }

    private var mediaPlayer: MediaPlayer? = null

    private fun playPowerUpTone() {
        try {
            mediaPlayer = MediaPlayer.create(this, R.raw.intro_whoosh)
            mediaPlayer?.setOnCompletionListener { it.release() }
            mediaPlayer?.start()
        } catch (_: Exception) {
            // Non-fatal if the device has no audio output available.
        }
    }

    private fun proceed() {
        val target = if (PermissionsActivity.needsOnboarding(this))
            Intent(this, PermissionsActivity::class.java)
        else
            Intent(this, MainActivity::class.java)
        startActivity(target)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
