package com.likas.boost

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class TermsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms)
        ThemeManager.applyStatusBar(this)

        findViewById<TextView>(R.id.termsText).text = """
            LIKAS — Terms and Conditions

            Last updated: 2026

            1. Purpose
            LIKAS is a device-performance and connectivity utility. It provides network diagnostics, a Do Not Disturb game mode, a device memory helper, and optional graphics-profile suggestions for supported games.

            2. What this app does not do
            LIKAS does not read, modify, or inject into the memory or files of any other running app. It does not provide gameplay advantages such as aim assistance, wallhacks, or unlocking of paid or restricted content. Any feature that would require that kind of access is intentionally not included.

            3. Permissions
            Overlay, notification, and Do Not Disturb permissions are requested once during setup and are used only for the features described in-app. You can revoke any permission at any time from your device Settings.

            4. No warranty
            This app is provided "as is." Network conditions, device hardware, and each third-party game's own settings ultimately determine real-world results — LIKAS cannot guarantee a specific performance outcome.

            5. Third-party games
            LIKAS is not affiliated with, endorsed by, or sponsored by any game publisher. Use of any graphics-profile feature must comply with that game's own terms of service.

            6. Contact
            Developed by Jeric B. Salvaleon.

            © 2026 Jeric B. Salvaleon. All rights reserved.
        """.trimIndent()
    }
}
