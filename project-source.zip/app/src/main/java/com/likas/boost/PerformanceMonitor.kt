package com.likas.boost

import android.content.Context
import android.os.Build
import android.os.PowerManager
import java.io.RandomAccessFile

/**
 * "Performance Monitor" — honestly scoped. A third-party app cannot read
 * another app's live FPS; there's no supported Android API for that
 * without special system access. What this class actually reads, all of
 * it real and documented:
 *   - Aggregate system-wide CPU load, parsed from /proc/stat (the same
 *     file `top` reads). On some OEM/Android-version combinations this
 *     file is restricted; this fails soft to null rather than guessing.
 *   - Device thermal status via PowerManager.getCurrentThermalStatus()
 *     (API 29+, no special permission needed) — a real signal for
 *     "is this device throttling," even though it isn't a temperature
 *     in degrees.
 */
class PerformanceMonitor(private val context: Context) {

    private var lastSample: CpuUsageCalculator.CpuTimes? = null

    /** Returns null if /proc/stat isn't readable on this device (fails soft, never fakes a number). */
    fun sampleCpuUsagePercent(): Double? {
        val current = readProcStatLine()?.let { CpuUsageCalculator.parse(it) } ?: return null
        val previous = lastSample
        lastSample = current
        return if (previous != null) CpuUsageCalculator.usagePercent(previous, current) else null
    }

    private fun readProcStatLine(): String? {
        return try {
            RandomAccessFile("/proc/stat", "r").use { it.readLine() }
        } catch (e: Exception) {
            null // restricted on this device — honest null, not a fabricated value
        }
    }

    enum class ThermalLevel { NOMINAL, LIGHT, MODERATE, SEVERE, CRITICAL, UNKNOWN }

    fun currentThermalLevel(): ThermalLevel {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return ThermalLevel.UNKNOWN
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NOMINAL
            PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
            PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
            PowerManager.THERMAL_STATUS_SEVERE,
            PowerManager.THERMAL_STATUS_CRITICAL -> ThermalLevel.SEVERE
            PowerManager.THERMAL_STATUS_EMERGENCY,
            PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.CRITICAL
            else -> ThermalLevel.UNKNOWN
        }
    }
}
