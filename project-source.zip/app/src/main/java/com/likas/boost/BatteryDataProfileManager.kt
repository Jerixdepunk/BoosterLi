package com.likas.boost

/**
 * Pure decision logic (no Android dependency, fully unit-testable) for
 * choosing a battery/data profile. Tuned for weak-signal / metered-data
 * situations such as rural or mountainous areas.
 */
class BatteryDataProfileManager {

    enum class Profile { NORMAL, DATA_SAVER, CRITICAL_SAVER }

    data class DeviceState(
        val batteryPct: Int,
        val isMetered: Boolean,
        val signalQuality: NetworkQualityMonitor.Quality
    )

    fun decide(state: DeviceState): Profile {
        val weakSignal = state.signalQuality == NetworkQualityMonitor.Quality.POOR ||
            state.signalQuality == NetworkQualityMonitor.Quality.OFFLINE

        return when {
            state.batteryPct <= 15 -> Profile.CRITICAL_SAVER
            state.batteryPct <= 30 && weakSignal -> Profile.CRITICAL_SAVER
            state.isMetered && weakSignal -> Profile.DATA_SAVER
            state.batteryPct <= 40 -> Profile.DATA_SAVER
            else -> Profile.NORMAL
        }
    }
}
