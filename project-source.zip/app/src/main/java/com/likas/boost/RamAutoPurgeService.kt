package com.likas.boost

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/**
 * Polls memory pressure periodically and triggers MemoryOptimizer's
 * best-effort trim once usage crosses a threshold — the "automated purge
 * on spike" feature. Being honest about scope: this polls
 * ActivityManager.MemoryInfo (a real, permitted signal) rather than
 * "detecting FPS drops," since third-party apps have no supported way to
 * read another app's live frame rate. High memory pressure and stutter are
 * correlated closely enough in practice that reacting to memory pressure
 * is a reasonable, honest proxy — it just isn't literally frame-timing
 * telemetry from the foreground game.
 */
class RamAutoPurgeService : Service() {

    companion object {
        const val CHANNEL_ID = "likas_autopurge_channel"
        const val NOTIF_ID = 46
        private const val POLL_INTERVAL_MS = 15_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var memoryOptimizer: MemoryOptimizer
    private var lastTriggerAt = 0L
    private lateinit var pollRunnable: Runnable

    override fun onCreate() {
        super.onCreate()
        memoryOptimizer = MemoryOptimizer(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        startPolling()
        return START_STICKY
    }

    private fun startPolling() {
        pollRunnable = object : Runnable {
            override fun run() {
                checkAndPurgeIfNeeded()
                handler.postDelayed(this, POLL_INTERVAL_MS)
            }
        }
        handler.post(pollRunnable)
    }

    private fun checkAndPurgeIfNeeded() {
        val snap = memoryOptimizer.snapshot()
        if (snap.totalMb <= 0) return
        val usedRatio = 1.0 - (snap.availMb.toDouble() / snap.totalMb.toDouble())
        val now = System.currentTimeMillis()

        if (RamPurgeDecision.shouldTrigger(usedRatio, snap.lowMemory, now - lastTriggerAt)) {
            lastTriggerAt = now
            memoryOptimizer.clearOwnCache()
            memoryOptimizer.requestTrim(commonCacheHeavyPackages())
        }
    }

    /**
     * A short, conservative list of package names commonly left running in
     * the background with large caches (browsers, social/media apps). Never
     * includes system packages or the foreground game itself — this only
     * ever asks the OS to trim cached processes, per MemoryOptimizer's
     * documented real scope.
     */
    private fun commonCacheHeavyPackages(): List<String> = listOf(
        "com.android.chrome",
        "com.facebook.katana",
        "com.facebook.orca",
        "com.instagram.android",
        "com.google.android.youtube",
        "com.whatsapp"
    )

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "LIKAS Auto Memory Purge", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LIKAS")
            .setContentText("Watching memory pressure in the background")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
