package com.likas.boost

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var dndManager: DndModeManager
    private lateinit var memoryOptimizer: MemoryOptimizer
    private lateinit var wifiLock: WifiPerformanceLock
    private lateinit var refreshRateManager: RefreshRateManager
    private lateinit var brightnessLockManager: BrightnessLockManager
    private lateinit var batterySaverManager: BatterySaverManager
    private lateinit var gameProfileManager: GameProfileManager
    private lateinit var quickLaunchManager: QuickLaunchManager
    private lateinit var dndScheduleManager: DndScheduleManager

    private var pendingRecordingMode = "record" // "record" or "screenshot"

    private val screenCaptureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenRecorderService::class.java).apply {
                putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenRecorderService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenRecorderService.EXTRA_MODE, pendingRecordingMode)
            }
            ContextCompat.startForegroundService(this, intent)
        } else {
            Toast.makeText(this, "Screen capture permission was not granted", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ThemeManager.applyStatusBar(this)

        dndManager = DndModeManager(this)
        memoryOptimizer = MemoryOptimizer(this)
        wifiLock = WifiPerformanceLock(this)
        refreshRateManager = RefreshRateManager(this)
        brightnessLockManager = BrightnessLockManager(this)
        batterySaverManager = BatterySaverManager(this)
        gameProfileManager = GameProfileManager(this)
        quickLaunchManager = QuickLaunchManager(this)
        dndScheduleManager = DndScheduleManager(this)

        findViewById<android.widget.ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        setupOverlaySwitch()
        setupDndSwitch()
        setupDndScheduleCard()
        setupMemoryCard()
        setupAutoPurgeCard()
        setupBatterySaverCard()
        setupWifiLockCard()
        setupRefreshRateCard()
        setupBrightnessCard()
        setupQuickLaunchCard()
        setupRecorderCard()
        setupProfilesCard()
    }

    override fun onResume() {
        super.onResume()
        refreshQuickLaunchList()
    }

    // --- Overlay toggle ---

    private fun setupOverlaySwitch() {
        val switchOverlay = findViewById<Switch>(R.id.switchOverlay)
        ThemeManager.styleSwitch(switchOverlay, this)
        switchOverlay.isChecked = Settings.canDrawOverlays(this) && isServiceLikelyRunning()

        switchOverlay.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    switchOverlay.isChecked = false
                    Toast.makeText(this, "Grant overlay permission, then turn this on again", Toast.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                ContextCompat.startForegroundService(this, Intent(this, BoosterOverlayService::class.java))
                Toast.makeText(this, "Overlay active — drag the bubble anywhere", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, BoosterOverlayService::class.java))
            }
        }
    }

    private fun isServiceLikelyRunning(): Boolean = false // best-effort UI state only

    // --- Game Mode / DND ---

    private fun setupDndSwitch() {
        val switchDnd = findViewById<Switch>(R.id.switchDnd)
        ThemeManager.styleSwitch(switchDnd, this)
        switchDnd.isChecked = dndManager.isSessionActive()

        switchDnd.setOnCheckedChangeListener { _, isChecked ->
            if (!dndManager.hasDndAccess()) {
                startActivity(dndManager.requestDndAccessIntent())
                switchDnd.isChecked = false
                Toast.makeText(this, "Grant Do Not Disturb access, then try again", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            if (isChecked) dndManager.startGameMode() else dndManager.stopGameMode()
        }
    }

    // --- Game Mode Schedule ---

    private fun setupDndScheduleCard() {
        val schedule = dndScheduleManager.getSchedule()
        updateScheduleStatusText(schedule)

        val switchSchedule = findViewById<Switch>(R.id.switchDndSchedule)
        ThemeManager.styleSwitch(switchSchedule, this)
        switchSchedule.isChecked = schedule.enabled

        val btnStart = findViewById<android.widget.Button>(R.id.btnScheduleStart)
        val btnEnd = findViewById<android.widget.Button>(R.id.btnScheduleEnd)
        ThemeManager.styleButtonSecondary(btnStart, this)
        ThemeManager.styleButtonSecondary(btnEnd, this)

        btnStart.setOnClickListener { pickTime(schedule.startMinute) { minute -> saveScheduleField(startMinute = minute) } }
        btnEnd.setOnClickListener { pickTime(schedule.endMinute) { minute -> saveScheduleField(endMinute = minute) } }

        switchSchedule.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked && !dndManager.hasDndAccess()) {
                startActivity(dndManager.requestDndAccessIntent())
                switchSchedule.isChecked = false
                Toast.makeText(this, "Grant Do Not Disturb access first", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            val current = dndScheduleManager.getSchedule()
            val updated = current.copy(enabled = isChecked)
            dndScheduleManager.saveSchedule(updated)
            updateScheduleStatusText(updated)
        }
    }

    private fun pickTime(initialMinute: Int, onPicked: (Int) -> Unit) {
        val cal = Calendar.getInstance()
        TimePickerDialog(this, { _, hour, minute -> onPicked(hour * 60 + minute) }, initialMinute / 60, initialMinute % 60, true).show()
    }

    private fun saveScheduleField(startMinute: Int? = null, endMinute: Int? = null) {
        val current = dndScheduleManager.getSchedule()
        val updated = current.copy(
            startMinute = startMinute ?: current.startMinute,
            endMinute = endMinute ?: current.endMinute
        )
        dndScheduleManager.saveSchedule(updated)
        updateScheduleStatusText(updated)
    }

    private fun updateScheduleStatusText(schedule: DndScheduleManager.Schedule) {
        fun fmt(minute: Int) = String.format("%02d:%02d", minute / 60, minute % 60)
        findViewById<TextView>(R.id.dndScheduleStatusText).text =
            "${fmt(schedule.startMinute)} – ${fmt(schedule.endMinute)}" + if (schedule.enabled) " (active)" else " (off)"
    }

    // --- Memory optimizer ---

    private fun setupMemoryCard() {
        refreshMemoryText()
        val btn = findViewById<android.widget.Button>(R.id.btnCleanMemory)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener {
            val freedKb = memoryOptimizer.clearOwnCache()
            Toast.makeText(this, "Cleared ${freedKb}KB cache. Trimming background apps...", Toast.LENGTH_SHORT).show()
            refreshMemoryText()
        }
    }

    private fun refreshMemoryText() {
        val snap = memoryOptimizer.snapshot()
        findViewById<TextView>(R.id.memoryStatusText).text =
            "${snap.availMb} MB free of ${snap.totalMb} MB" + if (snap.lowMemory) " — device reports low memory" else ""
    }

    // --- Auto memory purge ---

    private fun setupAutoPurgeCard() {
        val switchAuto = findViewById<Switch>(R.id.switchAutoPurge)
        ThemeManager.styleSwitch(switchAuto, this)
        switchAuto.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                ContextCompat.startForegroundService(this, Intent(this, RamAutoPurgeService::class.java))
                Toast.makeText(this, "Watching memory pressure in the background", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, RamAutoPurgeService::class.java))
            }
        }
    }

    // --- Battery saver ---

    private fun setupBatterySaverCard() {
        val switchSaver = findViewById<Switch>(R.id.switchBatterySaver)
        ThemeManager.styleSwitch(switchSaver, this)
        switchSaver.setOnCheckedChangeListener { _, isChecked ->
            if (!batterySaverManager.canApply()) {
                batterySaverManager.requestPermission()
                switchSaver.isChecked = false
                Toast.makeText(this, "Grant 'Modify system settings', then turn this on again", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            if (isChecked) batterySaverManager.enable() else batterySaverManager.disable()
        }
    }

    // --- Wi-Fi performance lock ---

    private fun setupWifiLockCard() {
        val switchWifi = findViewById<Switch>(R.id.switchWifiLock)
        ThemeManager.styleSwitch(switchWifi, this)
        switchWifi.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                val ok = wifiLock.acquire()
                if (!ok) {
                    switchWifi.isChecked = false
                    Toast.makeText(this, "Couldn't acquire Wi-Fi lock on this device", Toast.LENGTH_SHORT).show()
                }
            } else {
                wifiLock.release()
            }
        }
    }

    // --- Refresh rate ---

    private fun setupRefreshRateCard() {
        val info = refreshRateManager.getDeviceRefreshInfo()
        findViewById<TextView>(R.id.refreshRateStatusText).text = if (info.supportsHighRefresh)
            "This device supports up to ${info.maxRefreshHz}Hz. LIKAS requests it for its own screens; enable it system-wide in Display settings for all apps."
        else
            "This device reports a standard 60Hz max — high refresh rate isn't available here."
        refreshRateManager.applyHighestRefreshToOwnWindow()

        val btn = findViewById<android.widget.Button>(R.id.btnOpenDisplaySettings)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
    }

    // --- Brightness lock ---

    private fun setupBrightnessCard() {
        val switchBrightness = findViewById<Switch>(R.id.switchBrightnessLock)
        ThemeManager.styleSwitch(switchBrightness, this)
        switchBrightness.setOnCheckedChangeListener { _, isChecked ->
            if (!brightnessLockManager.canWriteSettings()) {
                brightnessLockManager.requestWritePermission()
                switchBrightness.isChecked = false
                Toast.makeText(this, "Grant 'Modify system settings', then turn this on again", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            if (isChecked) {
                brightnessLockManager.lockBrightness(180)
            } else {
                brightnessLockManager.restoreAutoBrightness()
            }
        }
    }

    // --- Quick launch ---

    private fun setupQuickLaunchCard() {
        findViewById<android.widget.Button>(R.id.btnQuickLaunchRefresh).apply {
            ThemeManager.styleButtonSecondary(this, this@MainActivity)
            setOnClickListener { refreshQuickLaunchList() }
        }
        refreshQuickLaunchList()
    }

    private fun refreshQuickLaunchList() {
        val listContainer = findViewById<LinearLayout>(R.id.quickLaunchList)
        val statusText = findViewById<TextView>(R.id.quickLaunchStatusText)
        listContainer.removeAllViews()

        if (!quickLaunchManager.hasUsageAccess()) {
            statusText.text = "Grant Usage Access to see recent apps here."
            statusText.setOnClickListener { startActivity(quickLaunchManager.requestUsageAccessIntent()) }
            return
        }

        val recents = quickLaunchManager.getRecentLaunchableApps()
        if (recents.isEmpty()) {
            statusText.text = "No recent app activity found yet."
            return
        }
        statusText.text = "Tap to relaunch:"

        recents.forEach { app ->
            val row = android.widget.Button(this).apply {
                text = app.label
                isAllCaps = false
                setOnClickListener { quickLaunchManager.launch(app.packageName) }
            }
            ThemeManager.styleButtonSecondary(row, this)
            (row.layoutParams as? LinearLayout.LayoutParams)?.topMargin = 6
            listContainer.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = 6 })
        }
    }

    // --- Screen recorder ---

    private fun setupRecorderCard() {
        val btnStart = findViewById<android.widget.Button>(R.id.btnStartRecording)
        val btnStop = findViewById<android.widget.Button>(R.id.btnStopRecording)
        val btnShot = findViewById<android.widget.Button>(R.id.btnTakeScreenshot)
        listOf(btnStart, btnStop, btnShot).forEach { ThemeManager.styleButtonSecondary(it, this) }

        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        btnStart.setOnClickListener {
            pendingRecordingMode = "record"
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
        }
        btnShot.setOnClickListener {
            pendingRecordingMode = "screenshot"
            screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
        }
        btnStop.setOnClickListener {
            val intent = Intent(this, ScreenRecorderService::class.java).setAction(ScreenRecorderService.ACTION_STOP_RECORDING)
            startService(intent)
            Toast.makeText(this, "Recording saved to LIKAS's app folder", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Game profiles ---

    private fun setupProfilesCard() {
        val btn = findViewById<android.widget.Button>(R.id.btnManageProfiles)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener { showGamePickerForProfile() }
    }

    private fun showGamePickerForProfile() {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString() }

        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val packageNames = apps.map { it.activityInfo.packageName }

        android.app.AlertDialog.Builder(this)
            .setTitle("Save current settings for...")
            .setItems(labels) { _, which ->
                val pkg = packageNames[which]
                val profile = GameProfileManager.Profile(
                    packageName = pkg,
                    dndEnabled = dndManager.isSessionActive(),
                    batterySaverEnabled = findViewById<Switch>(R.id.switchBatterySaver).isChecked,
                    brightnessLockLevel = if (findViewById<Switch>(R.id.switchBrightnessLock).isChecked) 180 else -1
                )
                gameProfileManager.saveProfile(profile)
                Toast.makeText(this, "Profile saved for ${labels[which]}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}
