package com.likas.boost

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val dnsOptimizer = DnsOptimizer()
    private lateinit var dndManager: DndModeManager
    private lateinit var memoryOptimizer: MemoryOptimizer
    private lateinit var gfxProfileManager: GfxProfileManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dndManager = DndModeManager(this)
        memoryOptimizer = MemoryOptimizer(this)
        gfxProfileManager = GfxProfileManager(this)

        findViewById<android.widget.ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        setupOverlaySwitch()
        setupDndSwitch()
        setupMemoryCard()
        setupGfxCard()
        setupDnsCard()
    }

    // --- Overlay toggle ---

    private fun setupOverlaySwitch() {
        val switchOverlay = findViewById<Switch>(R.id.switchOverlay)
        switchOverlay.isChecked = Settings.canDrawOverlays(this) && isServiceLikelyRunning()

        switchOverlay.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    switchOverlay.isChecked = false
                    Toast.makeText(this, "Grant overlay permission, then turn this on again", Toast.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                startService(Intent(this, BoosterOverlayService::class.java))
                Toast.makeText(this, "Overlay active — drag the bubble anywhere", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, BoosterOverlayService::class.java))
            }
        }
    }

    private fun isServiceLikelyRunning(): Boolean = false // best-effort UI state only

    // --- Game Mode / DND ---

    private fun setupDndSwitch() {
        val switchDnd = findViewById<Switch>(R.id.switchDnd)
        switchDnd.isChecked = dndManager.isSessionActive()

        switchDnd.setOnCheckedChangeListener { _, isChecked ->
            if (!dndManager.hasDndAccess()) {
                startActivity(dndManager.requestDndAccessIntent())
                switchDnd.isChecked = false
                Toast.makeText(this, "Grant Do Not Disturb access, then try again", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            if (isChecked) dndManager.startGameMode() else dndManager.stopGameMode()
        }
    }

    // --- Memory optimizer ---

    private fun setupMemoryCard() {
        refreshMemoryText()
        findViewById<android.widget.Button>(R.id.btnCleanMemory).setOnClickListener {
            val freedKb = memoryOptimizer.clearOwnCache()
            Toast.makeText(this, "Cleared ${freedKb}KB cache. Trimming background apps...", Toast.LENGTH_SHORT).show()
            refreshMemoryText()
        }
    }

    private fun refreshMemoryText() {
        val snap = memoryOptimizer.snapshot()
        findViewById<TextView>(R.id.memoryStatusText).text =
            "${snap.availMb} MB free of ${snap.totalMb} MB" + if (snap.lowMemory) " — device reports low memory" else ""
    }

    // --- GFX profile ---

    private fun setupGfxCard() {
        findViewById<android.widget.Button>(R.id.btnGfxProfile).setOnClickListener {
            val presets = GfxProfileManager.Preset.values()
            val labels = presets.map { it.label }.toTypedArray()
            android.app.AlertDialog.Builder(this)
                .setTitle("Choose a graphics profile")
                .setItems(labels) { _, which ->
                    val chosen = presets[which]
                    gfxProfileManager.saveSelectedPreset("default", chosen)
                    Toast.makeText(
                        this,
                        "${chosen.label} saved. Note: this only takes effect for games that read a compatible config file — see Settings > Terms.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                .show()
        }
    }

    // --- DNS optimizer ---

    private fun setupDnsCard() {
        findViewById<android.widget.Button>(R.id.btnBenchmarkDns).setOnClickListener {
            val resultText = findViewById<TextView>(R.id.dnsResultText)
            resultText.text = "Benchmarking..."
            CoroutineScope(Dispatchers.Main).launch {
                val best = withContext(Dispatchers.IO) { dnsOptimizer.recommend() }
                resultText.text = if (best != null)
                    "Fastest: ${best.name} (${best.ip}) — ${best.rttMs} ms"
                else
                    "No resolver reachable. Check your connection."
            }
        }
    }
}
