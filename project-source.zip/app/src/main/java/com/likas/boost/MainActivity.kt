package com.likas.boost

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val dnsOptimizer = DnsOptimizer()
    private val dnsLockHelper = DnsLockHelper()
    private lateinit var dndManager: DndModeManager
    private lateinit var memoryOptimizer: MemoryOptimizer
    private lateinit var gfxProfileManager: GfxProfileManager
    private lateinit var wifiLock: WifiPerformanceLock
    private lateinit var refreshRateManager: RefreshRateManager
    private lateinit var brightnessLockManager: BrightnessLockManager
    private lateinit var gameProfileManager: GameProfileManager

    private var lastDnsRecommendation: DnsOptimizer.DnsResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ThemeManager.applyStatusBar(this)

        dndManager = DndModeManager(this)
        memoryOptimizer = MemoryOptimizer(this)
        gfxProfileManager = GfxProfileManager(this)
        wifiLock = WifiPerformanceLock(this)
        refreshRateManager = RefreshRateManager(this)
        brightnessLockManager = BrightnessLockManager(this)
        gameProfileManager = GameProfileManager(this)

        findViewById<android.widget.ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        setupOverlaySwitch()
        setupDndSwitch()
        setupMemoryCard()
        setupGfxCard()
        setupDnsCard()
        setupNightVisionCard()
        setupAutoPurgeCard()
        setupWifiLockCard()
        setupRefreshRateCard()
        setupBrightnessCard()
        setupProfilesCard()
    }

    // --- Overlay toggle ---

    private fun setupOverlaySwitch() {
        val switchOverlay = findViewById<Switch>(R.id.switchOverlay)
        ThemeManager.styleSwitch(switchOverlay, this)
        switchOverlay.isChecked = Settings.canDrawOverlays(this) && isServiceLikelyRunning()

        switchOverlay.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    switchOverlay.isChecked = false
                    Toast.makeText(this, "Grant overlay permission, then turn this on again", Toast.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                ContextCompat.startForegroundService(this, Intent(this, BoosterOverlayService::class.java))
                Toast.makeText(this, "Overlay active — drag the bubble anywhere", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, BoosterOverlayService::class.java))
            }
        }
    }

    private fun isServiceLikelyRunning(): Boolean = false // best-effort UI state only

    // --- Game Mode / DND ---

    private fun setupDndSwitch() {
        val switchDnd = findViewById<Switch>(R.id.switchDnd)
        ThemeManager.styleSwitch(switchDnd, this)
        switchDnd.isChecked = dndManager.isSessionActive()

        switchDnd.setOnCheckedChangeListener { _, isChecked ->
            if (!dndManager.hasDndAccess()) {
                startActivity(dndManager.requestDndAccessIntent())
                switchDnd.isChecked = false
                Toast.makeText(this, "Grant Do Not Disturb access, then try again", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            if (isChecked) dndManager.startGameMode() else dndManager.stopGameMode()
        }
    }

    // --- Memory optimizer ---

    private fun setupMemoryCard() {
        refreshMemoryText()
        val btn = findViewById<android.widget.Button>(R.id.btnCleanMemory)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener {
            val freedKb = memoryOptimizer.clearOwnCache()
            Toast.makeText(this, "Cleared ${freedKb}KB cache. Trimming background apps...", Toast.LENGTH_SHORT).show()
            refreshMemoryText()
        }
    }

    private fun refreshMemoryText() {
        val snap = memoryOptimizer.snapshot()
        findViewById<TextView>(R.id.memoryStatusText).text =
            "${snap.availMb} MB free of ${snap.totalMb} MB" + if (snap.lowMemory) " — device reports low memory" else ""
    }

    // --- GFX profile ---

    private fun setupGfxCard() {
        val btn = findViewById<android.widget.Button>(R.id.btnGfxProfile)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener {
            val presets = GfxProfileManager.Preset.values()
            val labels = presets.map { it.label }.toTypedArray()
            android.app.AlertDialog.Builder(this)
                .setTitle("Choose a graphics profile")
                .setItems(labels) { _, which ->
                    val chosen = presets[which]
                    gfxProfileManager.saveSelectedPreset("default", chosen)
                    Toast.makeText(
                        this,
                        "${chosen.label} saved. Note: this only takes effect for games that read a compatible config file — see Settings > Terms.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                .show()
        }
    }

    // --- DNS optimizer / "Ping Lock" ---

    private fun setupDnsCard() {
        val btnBenchmark = findViewById<android.widget.Button>(R.id.btnBenchmarkDns)
        val btnSetPrivateDns = findViewById<android.widget.Button>(R.id.btnSetPrivateDns)
        ThemeManager.styleButtonSecondary(btnBenchmark, this)
        ThemeManager.styleButtonSecondary(btnSetPrivateDns, this)

        btnBenchmark.setOnClickListener {
            val resultText = findViewById<TextView>(R.id.dnsResultText)
            resultText.text = "Benchmarking..."
            lifecycleScope.launch {
                val best = withContext(Dispatchers.IO) { dnsOptimizer.recommend() }
                lastDnsRecommendation = best
                resultText.text = if (best != null)
                    "Fastest: ${best.name} (${best.ip}) — ${best.rttMs} ms"
                else
                    "No resolver reachable. Check your connection."
            }
        }

        btnSetPrivateDns.setOnClickListener {
            val best = lastDnsRecommendation
            if (best == null) {
                Toast.makeText(this, "Run a DNS benchmark first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val hostname = dnsLockHelper.hostnameFor(best.name)
            if (hostname == null) {
                Toast.makeText(this, "No Private DNS hostname known for ${best.name}", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            dnsLockHelper.copyToClipboard(this, hostname)
            Toast.makeText(this, "Copied \"$hostname\" — paste it into Private DNS on the next screen", Toast.LENGTH_LONG).show()
            dnsLockHelper.openPrivateDnsSettings(this)
        }
    }

    // --- Night vision filter ---

    private fun setupNightVisionCard() {
        val switchNv = findViewById<Switch>(R.id.switchNightVision)
        val slider = findViewById<android.widget.SeekBar>(R.id.nightVisionSlider)
        ThemeManager.styleSwitch(switchNv, this)

        switchNv.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    switchNv.isChecked = false
                    Toast.makeText(this, "Grant overlay permission, then turn this on again", Toast.LENGTH_LONG).show()
                    return@setOnCheckedChangeListener
                }
                val intent = Intent(this, NightVisionOverlayService::class.java)
                intent.putExtra(NightVisionOverlayService.EXTRA_INTENSITY, slider.progress)
                ContextCompat.startForegroundService(this, intent)
            } else {
                stopService(Intent(this, NightVisionOverlayService::class.java))
            }
        }

        slider.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && switchNv.isChecked) {
                    val intent = Intent(this@MainActivity, NightVisionOverlayService::class.java)
                    intent.putExtra(NightVisionOverlayService.EXTRA_INTENSITY, progress)
                    ContextCompat.startForegroundService(this@MainActivity, intent)
                }
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
        })
    }

    // --- Auto memory purge ---

    private fun setupAutoPurgeCard() {
        val switchAuto = findViewById<Switch>(R.id.switchAutoPurge)
        ThemeManager.styleSwitch(switchAuto, this)
        switchAuto.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                ContextCompat.startForegroundService(this, Intent(this, RamAutoPurgeService::class.java))
                Toast.makeText(this, "Watching memory pressure in the background", Toast.LENGTH_SHORT).show()
            } else {
                stopService(Intent(this, RamAutoPurgeService::class.java))
            }
        }
    }

    // --- Wi-Fi performance lock ---

    private fun setupWifiLockCard() {
        val switchWifi = findViewById<Switch>(R.id.switchWifiLock)
        ThemeManager.styleSwitch(switchWifi, this)
        switchWifi.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                val ok = wifiLock.acquire()
                if (!ok) {
                    switchWifi.isChecked = false
                    Toast.makeText(this, "Couldn't acquire Wi-Fi lock on this device", Toast.LENGTH_SHORT).show()
                }
            } else {
                wifiLock.release()
            }
        }
    }

    // --- Refresh rate ---

    private fun setupRefreshRateCard() {
        val info = refreshRateManager.getDeviceRefreshInfo()
        findViewById<TextView>(R.id.refreshRateStatusText).text = if (info.supportsHighRefresh)
            "This device supports up to ${info.maxRefreshHz}Hz. LIKAS requests it for its own screens; enable it system-wide in Display settings for all apps."
        else
            "This device reports a standard 60Hz max — high refresh rate isn't available here."
        refreshRateManager.applyHighestRefreshToOwnWindow()

        val btn = findViewById<android.widget.Button>(R.id.btnOpenDisplaySettings)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
    }

    // --- Brightness lock ---

    private fun setupBrightnessCard() {
        val switchBrightness = findViewById<Switch>(R.id.switchBrightnessLock)
        ThemeManager.styleSwitch(switchBrightness, this)
        switchBrightness.setOnCheckedChangeListener { _, isChecked ->
            if (!brightnessLockManager.canWriteSettings()) {
                brightnessLockManager.requestWritePermission()
                switchBrightness.isChecked = false
                Toast.makeText(this, "Grant 'Modify system settings', then turn this on again", Toast.LENGTH_LONG).show()
                return@setOnCheckedChangeListener
            }
            if (isChecked) {
                brightnessLockManager.lockBrightness(180)
            } else {
                brightnessLockManager.restoreAutoBrightness()
            }
        }
    }

    // --- Game profiles ---

    private fun setupProfilesCard() {
        val btn = findViewById<android.widget.Button>(R.id.btnManageProfiles)
        ThemeManager.styleButtonSecondary(btn, this)
        btn.setOnClickListener { showGamePickerForProfile() }
    }

    private fun showGamePickerForProfile() {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString() }

        val labels = apps.map { it.loadLabel(pm).toString() }.toTypedArray()
        val packageNames = apps.map { it.activityInfo.packageName }

        android.app.AlertDialog.Builder(this)
            .setTitle("Save current settings for...")
            .setItems(labels) { _, which ->
                val pkg = packageNames[which]
                val profile = GameProfileManager.Profile(
                    packageName = pkg,
                    gfxPreset = gfxProfileManager.getSelectedPreset("default").name,
                    dndEnabled = dndManager.isSessionActive(),
                    nightVisionIntensity = findViewById<android.widget.SeekBar>(R.id.nightVisionSlider).progress,
                    brightnessLockLevel = if (findViewById<Switch>(R.id.switchBrightnessLock).isChecked) 180 else -1
                )
                gameProfileManager.saveProfile(profile)
                Toast.makeText(this, "Profile saved for ${labels[which]}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}
