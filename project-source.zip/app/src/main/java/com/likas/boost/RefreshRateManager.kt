package com.likas.boost

import android.app.Activity
import android.os.Build
import android.view.WindowManager

/**
 * "Refresh Rate Locker" — honestly scoped. A third-party app cannot force
 * another app's window to run at a specific refresh rate; that's an OS/
 * display-driver decision. What this class actually does:
 *   1. Requests the highest available refresh mode for LIKAS's *own*
 *      windows (useful for the overlay itself feeling smooth), via the
 *      real, documented Window.attributes.preferredDisplayModeId API.
 *   2. Reports whether the device already exposes a high-refresh mode at
 *      all, so the UI can show honest info instead of a fake toggle.
 * For actually raising the refresh rate while playing a *different* game,
 * the real mechanism is the device's own Settings > Display > "Smooth
 * Display" (or similar OEM wording) — this class can deep-link there
 * instead of pretending to control it directly.
 */
class RefreshRateManager(private val activity: Activity) {

    data class RefreshInfo(val supportsHighRefresh: Boolean, val maxRefreshHz: Int)

    fun getDeviceRefreshInfo(): RefreshInfo {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity.display
        } else {
            @Suppress("DEPRECATION")
            activity.windowManager.defaultDisplay
        } ?: return RefreshInfo(false, 60)

        val maxHz = display.supportedModes.maxOf { it.refreshRate }.toInt()
        return RefreshInfo(maxHz > 60, maxHz)
    }

    /** Applies the highest available refresh mode to LIKAS's own current window. */
    fun applyHighestRefreshToOwnWindow() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            activity.display
        } else {
            @Suppress("DEPRECATION")
            activity.windowManager.defaultDisplay
        } ?: return

        val bestMode = display.supportedModes.maxByOrNull { it.refreshRate } ?: return
        val params: WindowManager.LayoutParams = activity.window.attributes
        params.preferredDisplayModeId = bestMode.modeId
        activity.window.attributes = params
    }
}
