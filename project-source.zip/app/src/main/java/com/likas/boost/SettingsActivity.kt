package com.likas.boost

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.FrameLayout
import android.widget.GridLayout
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var btnTerms: android.widget.Button
    private lateinit var btnPerms: android.widget.Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        btnTerms = findViewById(R.id.btnTerms)
        btnPerms = findViewById(R.id.btnResetPermissions)

        ThemeManager.applyStatusBar(this)
        applyButtonTheme()
        buildThemeSwatches()

        btnTerms.setOnClickListener { startActivity(Intent(this, TermsActivity::class.java)) }
        btnPerms.setOnClickListener { startActivity(Intent(this, PermissionsActivity::class.java)) }
    }

    private fun applyButtonTheme() {
        ThemeManager.styleButtonSecondary(btnTerms, this)
        ThemeManager.styleButtonSecondary(btnPerms, this)
    }

    /**
     * Each swatch is a filled color dot inside a slightly larger ring frame.
     * The ring is only drawn (in the swatch's own color) when selected, so
     * selection reads as a clear glow rather than a small checkmark.
     */
    private fun buildThemeSwatches() {
        val grid = findViewById<GridLayout>(R.id.themeSwatchGrid)
        grid.removeAllViews()
        val selectedHex = ThemeManager.getAccentColorHex(this)
        val density = resources.displayMetrics.density

        ThemeManager.presetColors.forEach { (hex, _) ->
            val isSelected = hex.equals(selectedHex, ignoreCase = true)
            val outerSize = (64 * density).toInt()
            val dotSize = (40 * density).toInt()

            val frame = FrameLayout(this).apply {
                layoutParams = GridLayout.LayoutParams().apply {
                    width = outerSize
                    height = outerSize
                    setMargins(6, 6, 6, 6)
                }
                if (isSelected) {
                    background = ThemeManager.buildSwatchSelectionRing(this@SettingsActivity, hex)
                    elevation = 4 * density
                }
            }

            val dot = android.view.View(this).apply {
                layoutParams = FrameLayout.LayoutParams(dotSize, dotSize, android.view.Gravity.CENTER)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                }
                setOnClickListener {
                    ThemeManager.setAccentColor(this@SettingsActivity, hex)
                    // Re-apply everywhere on this screen immediately so the change feels live.
                    ThemeManager.applyStatusBar(this@SettingsActivity)
                    applyButtonTheme()
                    buildThemeSwatches()
                }
            }

            frame.addView(dot)
            grid.addView(frame)
        }
    }
}
