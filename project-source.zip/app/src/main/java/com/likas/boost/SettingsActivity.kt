package com.likas.boost

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var themeManager: ThemeManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        themeManager = ThemeManager(this)

        buildThemeSwatches()

        findViewById<android.widget.Button>(R.id.btnTerms).setOnClickListener {
            startActivity(Intent(this, TermsActivity::class.java))
        }
        findViewById<android.widget.Button>(R.id.btnResetPermissions).setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
    }

    private fun buildThemeSwatches() {
        val grid = findViewById<GridLayout>(R.id.themeSwatchGrid)
        grid.removeAllViews()
        val selected = themeManager.getSelected()

        ThemeManager.AccentTheme.values().forEach { theme ->
            val swatch = TextView(this).apply {
                text = if (theme == selected) "✓" else ""
                gravity = android.view.Gravity.CENTER
                setTextColor(if (theme == ThemeManager.AccentTheme.STELLAR_WHITE) Color.BLACK else Color.WHITE)
                val size = (72 * resources.displayMetrics.density).toInt()
                layoutParams = GridLayout.LayoutParams().apply {
                    width = size
                    height = size
                    setMargins(8, 8, 8, 8)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(theme.colorHex))
                }
                setOnClickListener {
                    themeManager.setSelected(theme)
                    buildThemeSwatches()
                }
            }
            grid.addView(swatch)
        }
    }
}
