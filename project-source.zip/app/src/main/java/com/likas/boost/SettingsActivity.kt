package com.likas.boost

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.widget.GridLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        buildThemeSwatches()

        findViewById<android.widget.Button>(R.id.btnTerms).setOnClickListener {
            startActivity(Intent(this, TermsActivity::class.java))
        }
        findViewById<android.widget.Button>(R.id.btnResetPermissions).setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
    }

    private fun buildThemeSwatches() {
        val grid = findViewById<GridLayout>(R.id.themeSwatchGrid)
        grid.removeAllViews()
        val selectedHex = ThemeManager.getAccentColorHex(this)

        ThemeManager.presetColors.forEach { (hex, _) ->
            val swatch = TextView(this).apply {
                text = if (hex.equals(selectedHex, ignoreCase = true)) "✓" else ""
                gravity = android.view.Gravity.CENTER
                setTextColor(if (hex.equals("#FFFFFF", ignoreCase = true)) Color.BLACK else Color.WHITE)
                val size = (72 * resources.displayMetrics.density).toInt()
                layoutParams = GridLayout.LayoutParams().apply {
                    width = size
                    height = size
                    setMargins(8, 8, 8, 8)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(hex))
                }
                setOnClickListener {
                    ThemeManager.setAccentColor(this@SettingsActivity, hex)
                    buildThemeSwatches()
                }
            }
            grid.addView(swatch)
        }
    }
}
