package com.likas.boost

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings

/**
 * "Quick Launch Panel" — implemented as a dashboard card listing recent
 * apps with a tap-to-launch button, not a separate floating widget. Adding
 * another persistent overlay component on top of the existing bubble would
 * meaningfully increase complexity and battery/permission surface for a
 * convenience feature; this delivers the same real functionality (see
 * recent apps, launch one) without that cost. A floating version could be
 * added later as its own scoped change if it turns out to be missed.
 *
 * Uses UsageStatsManager, which requires the special "Usage access"
 * permission — a real, standard Android permission many utility/launcher
 * apps use, granted via its own settings screen (not a runtime dialog).
 */
class QuickLaunchManager(private val context: Context) {

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun requestUsageAccessIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    data class RecentApp(val packageName: String, val label: String)

    /** Returns up to [limit] recently-used launchable apps, most recent first. */
    fun getRecentLaunchableApps(limit: Int = 6): List<RecentApp> {
        if (!hasUsageAccess()) return emptyList()

        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - (24 * 60 * 60 * 1000L) // last 24h
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end) ?: emptyList()

        val pm = context.packageManager
        val launchablePackages = getLaunchablePackageNames(pm)

        return stats
            .filter { it.packageName in launchablePackages && it.lastTimeUsed > 0 }
            .sortedByDescending { it.lastTimeUsed }
            .distinctBy { it.packageName }
            .take(limit)
            .mapNotNull { stat ->
                try {
                    val label = pm.getApplicationLabel(pm.getApplicationInfo(stat.packageName, 0)).toString()
                    RecentApp(stat.packageName, label)
                } catch (e: PackageManager.NameNotFoundException) {
                    null
                }
            }
    }

    private fun getLaunchablePackageNames(pm: PackageManager): Set<String> {
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcherIntent, 0).map { it.activityInfo.packageName }.toSet()
    }

    fun launch(packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }
}
