package com.likas.boost

/**
 * One VPN server the user has configured — their own VPS or a config
 * exported from a VPN provider. LIKAS ships with none of these; the user
 * adds them via AddServerActivity (paste a .conf) after setting up a
 * server. See README for how to stand up a cheap one.
 */
data class VpnServerProfile(
    val countryName: String,
    val countryCode: String, // ISO 3166-1 alpha-2, e.g. "JP", used to pick a flag emoji
    val host: String,
    val port: Int,
    val clientPrivateKey: String,
    val clientAddress: String,
    val serverPublicKey: String,
    val dns: String,
    val allowedIps: String
) {
    /** Converts a 2-letter country code to its flag emoji via Unicode regional indicators. */
    fun flagEmoji(): String {
        if (countryCode.length != 2) return "🌐"
        val base = 0x1F1E6
        val chars = countryCode.uppercase().map { base + (it - 'A') }
        return chars.joinToString("") { String(Character.toChars(it)) }
    }
}
