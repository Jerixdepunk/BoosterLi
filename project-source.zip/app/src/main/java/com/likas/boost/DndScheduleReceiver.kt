package com.likas.boost

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DndScheduleReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val dndManager = DndModeManager(context)
        val scheduleManager = DndScheduleManager(context)

        when (intent.action) {
            DndScheduleManager.ACTION_START -> {
                if (dndManager.hasDndAccess()) dndManager.startGameMode()
            }
            DndScheduleManager.ACTION_STOP -> {
                if (dndManager.hasDndAccess()) dndManager.stopGameMode()
            }
        }

        // Inexact alarms are one-shot; reschedule tomorrow's occurrence if the feature is still enabled.
        val schedule = scheduleManager.getSchedule()
        if (schedule.enabled) scheduleManager.scheduleAlarms(schedule)
    }
}
