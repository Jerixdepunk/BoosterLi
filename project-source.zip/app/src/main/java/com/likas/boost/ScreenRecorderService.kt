package com.likas.boost

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Environment
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Screen recording and screenshot capture via Android's real MediaProjection
 * API — the same mechanism the OS's own built-in screen recorder uses.
 *
 * SCOPE NOTE: this captures video only, not internal game audio. Internal
 * audio capture (AudioPlaybackCaptureConfiguration, API 29+) adds real
 * complexity — many games opt their audio out of capture, and getting the
 * mixing/encoding right needs on-device testing I can't do in this
 * sandbox. Rather than ship an audio path I can't verify actually works,
 * this records video-only and says so; audio capture is a clearly-scoped
 * follow-up if wanted.
 */
class ScreenRecorderService : Service() {

    companion object {
        const val CHANNEL_ID = "likas_recorder_channel"
        const val NOTIF_ID = 47
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_MODE = "mode" // "record" or "screenshot"
        const val ACTION_STOP_RECORDING = "com.likas.boost.STOP_RECORDING"

        fun getOutputDir(context: Context, subDir: String): File {
            val dir = File(context.getExternalFilesDir(null), subDir)
            if (!dir.exists()) dir.mkdirs()
            return dir
        }
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var imageReader: ImageReader? = null
    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate() {
        super.onCreate()
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_RECORDING) {
            stopRecordingAndRelease()
            stopSelf()
            return START_NOT_STICKY
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        val mode = intent?.getStringExtra(EXTRA_MODE) ?: "record"

        if (resultData == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIF_ID, buildNotification(mode == "record"))
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        if (mode == "screenshot") captureScreenshot() else startRecording()

        return START_STICKY
    }

    private fun displayMetrics() = resources.displayMetrics

    private fun startRecording() {
        val dm = displayMetrics()
        val outFile = File(getOutputDir(this, Environment.DIRECTORY_MOVIES), "LIKAS_${timestamp()}.mp4")

        mediaRecorder = MediaRecorder().apply {
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoSize(dm.widthPixels, dm.heightPixels)
            setVideoFrameRate(30)
            setVideoEncodingBitRate(8_000_000)
            setOutputFile(outFile.absolutePath)
            prepare()
        }

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "LikasScreenRecord",
            dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            mediaRecorder!!.surface, null, null
        )

        mediaRecorder?.start()
    }

    private fun captureScreenshot() {
        val dm = displayMetrics()
        imageReader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "LikasScreenshot",
            dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            saveImageToFile(image)
            image.close()
            stopRecordingAndRelease()
            stopSelf()
        }, null)
    }

    private fun saveImageToFile(image: android.media.Image) {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width

            val bitmap = android.graphics.Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height, android.graphics.Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            val outFile = File(getOutputDir(this, Environment.DIRECTORY_PICTURES), "LIKAS_${timestamp()}.png")
            FileOutputStream(outFile).use { out ->
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out)
            }
            bitmap.recycle()
        } catch (e: Exception) {
            // Fails soft — the notification will simply not confirm a saved file.
        }
    }

    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun stopRecordingAndRelease() {
        try {
            mediaRecorder?.apply {
                stop()
                reset()
                release()
            }
        } catch (e: Exception) {
            // Recorder may not have started successfully — safe to ignore on teardown.
        }
        mediaRecorder = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        mediaProjection?.stop()
        mediaProjection = null
    }

    private fun buildNotification(isRecording: Boolean): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "LIKAS Screen Capture", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = Intent(this, ScreenRecorderService::class.java).setAction(ACTION_STOP_RECORDING)
        val stopPending = android.app.PendingIntent.getService(
            this, 0, stopIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LIKAS")
            .setContentText(if (isRecording) "Recording screen (video only, no audio)" else "Capturing screenshot...")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
        if (isRecording) builder.addAction(0, "Stop recording", stopPending)
        return builder.build()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRecordingAndRelease()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
