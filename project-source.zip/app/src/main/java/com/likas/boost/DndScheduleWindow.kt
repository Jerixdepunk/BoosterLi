package com.likas.boost

/**
 * Pure "is this minute-of-day inside the scheduled window" logic, kept
 * separate from DndScheduleManager (which touches AlarmManager/SharedPreferences)
 * so it's unit-testable without Robolectric. Minutes are 0–1439 (minutes
 * since midnight). Handles windows that cross midnight (e.g. 22:00–02:00).
 */
object DndScheduleWindow {

    fun isWithin(nowMinute: Int, startMinute: Int, endMinute: Int): Boolean {
        return if (startMinute <= endMinute) {
            nowMinute in startMinute until endMinute
        } else {
            // Wraps past midnight, e.g. start=22:00 (1320), end=02:00 (120)
            nowMinute >= startMinute || nowMinute < endMinute
        }
    }
}
