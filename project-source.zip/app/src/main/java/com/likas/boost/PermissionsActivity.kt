package com.likas.boost

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat

/**
 * Runs once (tracked via SharedPreferences) to walk the user through every
 * permission the app needs, then never shows again unless a permission gets
 * revoked later — matching the "ask once" requirement.
 */
class PermissionsActivity : AppCompatActivity() {

    companion object {
        private const val PREFS = "likas_prefs"
        private const val KEY_ONBOARDED = "onboarding_complete"

        fun needsOnboarding(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return !prefs.getBoolean(KEY_ONBOARDED, false) || !allPermissionsGranted(context)
        }

        fun allPermissionsGranted(context: Context): Boolean {
            val overlayOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                Settings.canDrawOverlays(context) else true
            val notifOk = NotificationManagerCompat.from(context).areNotificationsEnabled()
            return overlayOk && notifOk
        }

        fun markOnboarded(context: Context) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ONBOARDED, true).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permissions)

        findViewById<android.widget.Button>(R.id.btnGrantAll).setOnClickListener {
            requestOverlayIfNeeded()
        }
        findViewById<android.widget.Button>(R.id.btnContinue).setOnClickListener {
            markOnboarded(this)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatuses()
    }

    private fun requestOverlayIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
            return
        }
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }

    private fun refreshStatuses() {
        val overlayOk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(this) else true
        setStatus(R.id.permOverlayStatus, overlayOk)

        val notifOk = NotificationManagerCompat.from(this).areNotificationsEnabled()
        setStatus(R.id.permNotifStatus, notifOk)

        val nm = getSystemService(NotificationManager::class.java)
        setStatus(R.id.permDndStatus, nm.isNotificationPolicyAccessGranted)
    }

    private fun setStatus(viewId: Int, granted: Boolean) {
        val tv = findViewById<TextView>(viewId)
        tv.text = if (granted) "Granted" else "Not granted"
        tv.setTextColor(if (granted) 0xFF4CAF50.toInt() else 0xFFFF7043.toInt())
    }
}
