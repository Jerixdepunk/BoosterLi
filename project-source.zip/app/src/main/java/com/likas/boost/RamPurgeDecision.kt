package com.likas.boost

/**
 * Pure decision logic for whether the auto-purge should fire right now,
 * separated from RamAutoPurgeService so it's unit-testable without
 * Robolectric.
 */
object RamPurgeDecision {

    const val TRIGGER_THRESHOLD_PCT = 0.90
    const val COOLDOWN_MS = 60_000L

    /**
     * @param usedRatio fraction of total memory currently used (0.0–1.0)
     * @param lowMemory whether the OS itself reports low-memory state
     * @param msSinceLastTrigger time since the last purge fired
     */
    fun shouldTrigger(usedRatio: Double, lowMemory: Boolean, msSinceLastTrigger: Long): Boolean {
        val pressureDetected = usedRatio >= TRIGGER_THRESHOLD_PCT || lowMemory
        val cooldownElapsed = msSinceLastTrigger > COOLDOWN_MS
        return pressureDetected && cooldownElapsed
    }
}
