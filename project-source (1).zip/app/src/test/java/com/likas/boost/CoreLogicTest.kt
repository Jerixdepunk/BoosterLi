package com.likas.boost

import org.junit.Assert.assertEquals
import org.junit.Test

class CoreLogicTest {

    // --- DnsOptimizer.pickFastest ---

    @Test
    fun dns_picksLowestRttAmongReachable() {
        val opt = DnsOptimizer()
        val results = listOf(
            DnsOptimizer.DnsResult("A", "1.1.1.1", 40, true),
            DnsOptimizer.DnsResult("B", "8.8.8.8", 25, true),
            DnsOptimizer.DnsResult("C", "9.9.9.9", null, false)
        )
        assertEquals("B", opt.pickFastest(results)?.name)
    }

    @Test
    fun dns_returnsNullWhenNoneReachable() {
        val opt = DnsOptimizer()
        val results = listOf(
            DnsOptimizer.DnsResult("A", "1.1.1.1", null, false),
            DnsOptimizer.DnsResult("B", "8.8.8.8", null, false)
        )
        assertEquals(null, opt.pickFastest(results))
    }

    // --- NetworkQualityMonitor.classify ---

    @Test
    fun quality_excellentForLowPingLowLoss() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 30.0, packetLossPct = 0.0, jitterMs = 5.0))
        assertEquals(NetworkQualityMonitor.Quality.EXCELLENT, q)
    }

    @Test
    fun quality_poorForHighPing() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 400.0, packetLossPct = 10.0, jitterMs = 90.0))
        assertEquals(NetworkQualityMonitor.Quality.POOR, q)
    }

    @Test
    fun quality_offlineForHighPacketLoss() {
        val m = NetworkQualityMonitor()
        val q = m.classify(NetworkQualityMonitor.Sample(avgPingMs = 50.0, packetLossPct = 60.0, jitterMs = 5.0))
        assertEquals(NetworkQualityMonitor.Quality.OFFLINE, q)
    }

    @Test
    fun quality_jitterComputedAsStandardDeviation() {
        val m = NetworkQualityMonitor()
        val jitter = m.computeJitter(listOf(50.0, 50.0, 50.0))
        assertEquals(0.0, jitter, 0.001)
    }

    // --- BatteryDataProfileManager.decide ---

    @Test
    fun profile_criticalWhenBatteryVeryLow() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(10, isMetered = false, signalQuality = NetworkQualityMonitor.Quality.EXCELLENT)
        )
        assertEquals(BatteryDataProfileManager.Profile.CRITICAL_SAVER, p)
    }

    @Test
    fun profile_dataSaverWhenMeteredAndWeakSignal() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(80, isMetered = true, signalQuality = NetworkQualityMonitor.Quality.POOR)
        )
        assertEquals(BatteryDataProfileManager.Profile.DATA_SAVER, p)
    }

    @Test
    fun profile_normalWhenHealthyBatteryAndGoodSignal() {
        val mgr = BatteryDataProfileManager()
        val p = mgr.decide(
            BatteryDataProfileManager.DeviceState(90, isMetered = false, signalQuality = NetworkQualityMonitor.Quality.GOOD)
        )
        assertEquals(BatteryDataProfileManager.Profile.NORMAL, p)
    }

    // --- GfxProfileManager.Preset (pure enum values, no Android dependency) ---

    @Test
    fun gfxPreset_smoothPrioritizesFpsOverResolution() {
        val preset = GfxProfileManager.Preset.SMOOTH
        assertEquals(60, preset.fps)
        assertEquals(0.7f, preset.resolutionScale, 0.001f)
    }

    @Test
    fun gfxPreset_hdPrioritizesResolutionOverFps() {
        val preset = GfxProfileManager.Preset.HD
        assertEquals(1.0f, preset.resolutionScale, 0.001f)
        assertEquals(30, preset.fps)
    }

    // --- GameSessionStateMachine.start/stop (restores prior DND state) ---

    @Test
    fun sessionMachine_restoresWhateverFilterWasActiveBefore() {
        val sm = GameSessionStateMachine()
        val applied = sm.start(GameSessionStateMachine.InterruptionFilter.NONE)
        assertEquals(GameSessionStateMachine.InterruptionFilter.PRIORITY, applied)
        val restored = sm.stop()
        assertEquals(GameSessionStateMachine.InterruptionFilter.NONE, restored)
    }

    @Test
    fun sessionMachine_isActiveReflectsState() {
        val sm = GameSessionStateMachine()
        assertEquals(false, sm.isActive())
        sm.start(GameSessionStateMachine.InterruptionFilter.ALL)
        assertEquals(true, sm.isActive())
        sm.stop()
        assertEquals(false, sm.isActive())
    }

    // --- ColorUtils (pure hex math for the dynamic theme system) ---

    @Test
    fun colorUtils_darkenReducesEachChannel() {
        // 0x7C = 124, 124 * 0.5 = 62 = 0x3E
        val result = ColorUtils.darken("#7C4DFF", 0.5f)
        assertEquals("#3E", result.substring(0, 3))
    }

    @Test
    fun colorUtils_lightenMovesTowardWhite() {
        val result = ColorUtils.lighten("#000000", 1.0f)
        assertEquals("#FFFFFF", result)
    }

    @Test
    fun colorUtils_contrastingTextIsBlackOnLightBackground() {
        assertEquals("#000000", ColorUtils.contrastingTextColor("#FFFFFF"))
    }

    @Test
    fun colorUtils_contrastingTextIsWhiteOnDarkBackground() {
        assertEquals("#FFFFFF", ColorUtils.contrastingTextColor("#111111"))
    }

    // --- RamPurgeDecision.shouldTrigger ---

    @Test
    fun ramPurge_triggersWhenUsageCrossesThresholdAndCooldownElapsed() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.95, lowMemory = false, msSinceLastTrigger = 70_000)
        assertEquals(true, result)
    }

    @Test
    fun ramPurge_doesNotTriggerDuringCooldown() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.95, lowMemory = false, msSinceLastTrigger = 5_000)
        assertEquals(false, result)
    }

    @Test
    fun ramPurge_doesNotTriggerBelowThresholdEvenWithoutCooldown() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.5, lowMemory = false, msSinceLastTrigger = 999_999)
        assertEquals(false, result)
    }

    @Test
    fun ramPurge_osLowMemoryFlagTriggersEvenBelowRatioThreshold() {
        val result = RamPurgeDecision.shouldTrigger(usedRatio = 0.5, lowMemory = true, msSinceLastTrigger = 999_999)
        assertEquals(true, result)
    }

    // --- FloatingWindowController ---

    @Test
    fun floatingWindow_startsInWindowedMode() {
        val fw = FloatingWindowController(screenWidth = 1080, screenHeight = 2000)
        assertEquals(FloatingWindowController.Mode.WINDOWED, fw.mode)
    }

    @Test
    fun floatingWindow_minimizeThenRestoreReturnsToWindowed() {
        val fw = FloatingWindowController(screenWidth = 1080, screenHeight = 2000)
        fw.minimize()
        assertEquals(FloatingWindowController.Mode.MINIMIZED, fw.mode)
        fw.restoreFromMinimized()
        assertEquals(FloatingWindowController.Mode.WINDOWED, fw.mode)
    }

    @Test
    fun floatingWindow_toggleMaximizeThenToggleBackRestoresExactBounds() {
        val fw = FloatingWindowController(screenWidth = 1080, screenHeight = 2000)
        val original = FloatingWindowController.Bounds(x = 40, y = 100, width = 300, height = 400)
        fw.updateWindowedBounds(original)

        fw.toggleMaximize()
        assertEquals(FloatingWindowController.Mode.MAXIMIZED, fw.mode)
        val maxBounds = fw.currentBounds()
        assertEquals(1080 - 16 * 2, maxBounds.width)

        fw.toggleMaximize()
        assertEquals(FloatingWindowController.Mode.WINDOWED, fw.mode)
        assertEquals(original, fw.currentBounds())
    }

    @Test
    fun floatingWindow_clampRejectsBelowMinimumSize() {
        val fw = FloatingWindowController(screenWidth = 1080, screenHeight = 2000, minWidth = 220, minHeight = 260)
        val tooSmall = FloatingWindowController.Bounds(x = 0, y = 0, width = 50, height = 50)
        val clamped = fw.clampToWindowed(tooSmall)
        assertEquals(220, clamped.width)
        assertEquals(260, clamped.height)
    }

    @Test
    fun floatingWindow_clampKeepsWindowFullyOnScreen() {
        val fw = FloatingWindowController(screenWidth = 1080, screenHeight = 2000)
        val offScreen = FloatingWindowController.Bounds(x = 2000, y = 3000, width = 300, height = 400)
        val clamped = fw.clampToWindowed(offScreen)
        assertEquals(true, clamped.x + clamped.width <= 1080)
        assertEquals(true, clamped.y + clamped.height <= 2000)
    }

    @Test
    fun floatingWindow_minimizedBoundsAreFixedIconSize() {
        val fw = FloatingWindowController(screenWidth = 1080, screenHeight = 2000)
        fw.minimize()
        val bounds = fw.currentBounds()
        assertEquals(56, bounds.width)
        assertEquals(56, bounds.height)
    }
}
