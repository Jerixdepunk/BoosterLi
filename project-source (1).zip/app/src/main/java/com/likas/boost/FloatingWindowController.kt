package com.likas.boost

/**
 * Pure state machine + geometry math for the floating window's three
 * modes. Separated from FloatingWindowService so the sizing/clamping logic
 * can be verified with real unit tests instead of only trusted by
 * inspection.
 */
class FloatingWindowController(
    private val screenWidth: Int,
    private val screenHeight: Int,
    private val minWidth: Int = 220,
    private val minHeight: Int = 260,
    private val maximizeMargin: Int = 16
) {
    enum class Mode { MINIMIZED, WINDOWED, MAXIMIZED }

    data class Bounds(val x: Int, val y: Int, val width: Int, val height: Int)

    var mode: Mode = Mode.WINDOWED
        private set

    /** Remembers the last windowed bounds so minimize/maximize can restore into them. */
    var lastWindowedBounds: Bounds = Bounds(
        x = 40, y = 120, width = 260, height = 360
    )
        private set

    fun updateWindowedBounds(bounds: Bounds) {
        if (mode == Mode.WINDOWED) lastWindowedBounds = clampToWindowed(bounds)
    }

    fun minimize() {
        mode = Mode.MINIMIZED
    }

    fun restoreFromMinimized() {
        mode = Mode.WINDOWED
    }

    fun maximize() {
        mode = Mode.MAXIMIZED
    }

    /** Toggles between windowed and maximized; a no-op from MINIMIZED (must restore first). */
    fun toggleMaximize() {
        mode = when (mode) {
            Mode.MAXIMIZED -> Mode.WINDOWED
            Mode.WINDOWED -> Mode.MAXIMIZED
            Mode.MINIMIZED -> Mode.MINIMIZED
        }
    }

    fun currentBounds(): Bounds = when (mode) {
        Mode.MINIMIZED -> Bounds(lastWindowedBounds.x, lastWindowedBounds.y, 56, 56)
        Mode.WINDOWED -> lastWindowedBounds
        Mode.MAXIMIZED -> Bounds(
            x = maximizeMargin,
            y = maximizeMargin,
            width = screenWidth - maximizeMargin * 2,
            height = screenHeight - maximizeMargin * 2
        )
    }

    /** Clamps a proposed resize/move to stay within min size and on-screen. */
    fun clampToWindowed(proposed: Bounds): Bounds {
        val width = proposed.width.coerceIn(minWidth, screenWidth - 20)
        val height = proposed.height.coerceIn(minHeight, screenHeight - 20)
        val x = proposed.x.coerceIn(0, (screenWidth - width).coerceAtLeast(0))
        val y = proposed.y.coerceIn(0, (screenHeight - height).coerceAtLeast(0))
        return Bounds(x, y, width, height)
    }
}
