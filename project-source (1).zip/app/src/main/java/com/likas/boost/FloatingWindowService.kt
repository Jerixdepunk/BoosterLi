package com.likas.boost

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * The floating window: starts in a resizable WINDOWED panel over whatever
 * app is in the foreground. Title-bar controls let the user minimize it to
 * just the app icon, maximize it to near-fullscreen, or close it entirely.
 * All geometry/state-transition decisions are delegated to
 * FloatingWindowController (unit-tested separately) — this class only
 * translates that into real WindowManager calls.
 */
class FloatingWindowService : Service() {

    companion object {
        const val CHANNEL_ID = "likas_floating_window_channel"
        const val NOTIF_ID = 43
    }

    private lateinit var windowManager: WindowManager
    private lateinit var controller: FloatingWindowController
    private lateinit var params: WindowManager.LayoutParams
    private var rootView: View? = null
    private var isMinimizedView = false
    private val density get() = resources.displayMetrics.density

    private val statsHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private lateinit var statsRunnable: Runnable

    private lateinit var wifiLock: WifiPerformanceLock
    private lateinit var dndManager: DndModeManager
    private lateinit var memoryOptimizer: MemoryOptimizer

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        controller = FloatingWindowController(
            screenWidth = dm.widthPixels,
            screenHeight = dm.heightPixels,
            minWidth = (220 * density).toInt(),
            minHeight = (260 * density).toInt()
        )
        wifiLock = WifiPerformanceLock(this)
        dndManager = DndModeManager(this)
        memoryOptimizer = MemoryOptimizer(this)

        renderCurrentMode()
        startStatsLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        return START_STICKY
    }

    // --- Rendering the current mode ---

    private fun renderCurrentMode() {
        removeCurrentView()
        if (controller.mode == FloatingWindowController.Mode.MINIMIZED) {
            addMinimizedView()
        } else {
            addWindowedOrMaximizedView()
        }
    }

    private fun removeCurrentView() {
        rootView?.let { runCatching { windowManager.removeView(it) } }
        rootView = null
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else
        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addMinimizedView() {
        isMinimizedView = true
        val view = LayoutInflater.from(this).inflate(R.layout.floating_window_minimized, null)
        val bounds = controller.currentBounds()

        params = WindowManager.LayoutParams(
            (56 * density).toInt(),
            (56 * density).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bounds.x
        params.y = bounds.y

        windowManager.addView(view, params)
        rootView = view
        setupMinimizedTouch(view)
    }

    private fun addWindowedOrMaximizedView() {
        isMinimizedView = false
        val view = LayoutInflater.from(this).inflate(R.layout.floating_window, null)
        val bounds = controller.currentBounds()

        params = WindowManager.LayoutParams(
            bounds.width,
            bounds.height,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = bounds.x
        params.y = bounds.y

        windowManager.addView(view, params)
        rootView = view

        applyTheme(view)
        setupTitleBarDrag(view)
        setupControlButtons(view)
        setupResizeHandle(view)
        setupQuickControls(view)

        view.findViewById<View>(R.id.fwResizeHandle).visibility =
            if (controller.mode == FloatingWindowController.Mode.WINDOWED) View.VISIBLE else View.GONE
        view.findViewById<TextView>(R.id.fwBtnMaximize).text =
            if (controller.mode == FloatingWindowController.Mode.MAXIMIZED) "Min" else "Max"
    }

    private fun applyTheme(view: View) {
        val accentHex = ThemeManager.getAccentColorHex(this)
        view.findViewById<TextView>(R.id.fwTitleText).setTextColor(android.graphics.Color.parseColor(accentHex))
        view.findViewById<android.widget.Button>(R.id.fwBtnOptimizeMemory).let { ThemeManager.styleButtonSecondary(it, this) }
        view.findViewById<android.widget.Button>(R.id.fwBtnOpenApp).let { ThemeManager.styleButtonSecondary(it, this) }
    }

    // --- Minimized icon: tap anywhere to restore ---

    private fun setupMinimizedTouch(view: View) {
        var downX = 0f
        var downY = 0f
        var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(event.rawX - downX) > 8 || abs(event.rawY - downY) > 8) {
                        moved = true
                        params.x = (params.x + (event.rawX - downX)).toInt()
                        params.y = (params.y + (event.rawY - downY)).toInt()
                        downX = event.rawX; downY = event.rawY
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        controller.restoreFromMinimized()
                        controller.updateWindowedBounds(
                            FloatingWindowController.Bounds(params.x, params.y, controller.lastWindowedBounds.width, controller.lastWindowedBounds.height)
                        )
                        renderCurrentMode()
                    }
                    true
                }
                else -> false
            }
        }
    }

    // --- Title bar: drag to move (only the empty area, not the buttons) ---

    private fun setupTitleBarDrag(view: View) {
        val titleBar = view.findViewById<View>(R.id.fwTitleBar)
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        titleBar.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (controller.mode == FloatingWindowController.Mode.WINDOWED) {
                        controller.updateWindowedBounds(
                            FloatingWindowController.Bounds(params.x, params.y, params.width, params.height)
                        )
                    }
                    true
                }
                else -> false
            }
        }
    }

    // --- Minimize / Maximize / Close buttons ---

    private fun setupControlButtons(view: View) {
        view.findViewById<TextView>(R.id.fwBtnMinimize).setOnClickListener {
            if (controller.mode == FloatingWindowController.Mode.WINDOWED) {
                controller.updateWindowedBounds(
                    FloatingWindowController.Bounds(params.x, params.y, params.width, params.height)
                )
            }
            controller.minimize()
            renderCurrentMode()
        }

        view.findViewById<TextView>(R.id.fwBtnMaximize).setOnClickListener {
            if (controller.mode == FloatingWindowController.Mode.WINDOWED) {
                controller.updateWindowedBounds(
                    FloatingWindowController.Bounds(params.x, params.y, params.width, params.height)
                )
            }
            controller.toggleMaximize()
            renderCurrentMode()
        }

        view.findViewById<TextView>(R.id.fwBtnClose).setOnClickListener {
            stopSelf()
        }
    }

    // --- Resize handle: bottom-right corner drag ---

    private fun setupResizeHandle(view: View) {
        val handle = view.findViewById<View>(R.id.fwResizeHandle)
        var startWidth = 0
        var startHeight = 0
        var touchX = 0f
        var touchY = 0f

        handle.setOnTouchListener { _, event ->
            if (controller.mode != FloatingWindowController.Mode.WINDOWED) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startWidth = params.width; startHeight = params.height
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val proposed = FloatingWindowController.Bounds(
                        x = params.x,
                        y = params.y,
                        width = startWidth + (event.rawX - touchX).toInt(),
                        height = startHeight + (event.rawY - touchY).toInt()
                    )
                    val clamped = controller.clampToWindowed(proposed)
                    params.width = clamped.width
                    params.height = clamped.height
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    controller.updateWindowedBounds(
                        FloatingWindowController.Bounds(params.x, params.y, params.width, params.height)
                    )
                    true
                }
                else -> false
            }
        }
    }

    // --- Quick controls inside the window content ---

    private fun setupQuickControls(view: View) {
        val switchDnd = view.findViewById<Switch>(R.id.fwSwitchDnd)
        ThemeManager.styleSwitch(switchDnd, this)
        switchDnd.isChecked = dndManager.isSessionActive()
        switchDnd.setOnCheckedChangeListener { _, checked ->
            if (!dndManager.hasDndAccess()) {
                val intent = dndManager.requestDndAccessIntent()
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(intent)
                switchDnd.isChecked = false
                return@setOnCheckedChangeListener
            }
            if (checked) dndManager.startGameMode() else dndManager.stopGameMode()
        }

        val switchNv = view.findViewById<Switch>(R.id.fwSwitchNightVision)
        val nvSlider = view.findViewById<android.widget.SeekBar>(R.id.fwNightVisionSlider)
        ThemeManager.styleSwitch(switchNv, this)
        switchNv.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                val intent = Intent(this, NightVisionOverlayService::class.java)
                intent.putExtra(NightVisionOverlayService.EXTRA_INTENSITY, nvSlider.progress)
                ContextCompat.startForegroundService(this, intent)
            } else {
                stopService(Intent(this, NightVisionOverlayService::class.java))
            }
        }

        val switchAutoPurge = view.findViewById<Switch>(R.id.fwSwitchAutoPurge)
        ThemeManager.styleSwitch(switchAutoPurge, this)
        switchAutoPurge.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                ContextCompat.startForegroundService(this, Intent(this, RamAutoPurgeService::class.java))
            } else {
                stopService(Intent(this, RamAutoPurgeService::class.java))
            }
        }

        val switchWifi = view.findViewById<Switch>(R.id.fwSwitchWifiLock)
        ThemeManager.styleSwitch(switchWifi, this)
        switchWifi.isChecked = wifiLock.isHeld()
        switchWifi.setOnCheckedChangeListener { _, checked ->
            if (checked) wifiLock.acquire() else wifiLock.release()
        }

        view.findViewById<android.widget.Button>(R.id.fwBtnOptimizeMemory).setOnClickListener {
            val freedKb = memoryOptimizer.clearOwnCache()
            android.widget.Toast.makeText(this, "Cleared ${freedKb}KB cache", android.widget.Toast.LENGTH_SHORT).show()
        }

        view.findViewById<android.widget.Button>(R.id.fwBtnOpenApp).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    // --- Live stats (ping/battery/RAM), only relevant while not minimized ---

    private fun startStatsLoop() {
        statsRunnable = object : Runnable {
            override fun run() {
                updateStatsDisplay()
                statsHandler.postDelayed(this, 3000)
            }
        }
        statsHandler.post(statsRunnable)
    }

    private fun updateStatsDisplay() {
        if (isMinimizedView) return
        val view = rootView ?: return
        val batteryPct = getBatteryPercent()
        val ramInfo = memoryOptimizer.snapshot()
        view.findViewById<TextView>(R.id.fwStatBattery)?.text = "Battery: $batteryPct%"
        view.findViewById<TextView>(R.id.fwStatRam)?.text = "Free RAM: ${ramInfo.availMb} MB"
    }

    fun updatePing(rttMs: Long?) {
        if (isMinimizedView) return
        rootView?.findViewById<TextView>(R.id.fwStatPing)?.text =
            if (rttMs != null) "Ping: $rttMs ms" else "Ping: unreachable"
    }

    private fun getBatteryPercent(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "LIKAS Floating Window", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LIKAS")
            .setContentText("Floating window active")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        statsHandler.removeCallbacksAndMessages(null)
        removeCurrentView()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
