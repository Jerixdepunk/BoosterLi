# LIKAS

A gaming-utility Android app with an animated splash intro, a one-time
permission flow, and a **floating window** that hosts the app's quick
controls over any other app or game — drag to move, drag the corner to
resize, minimize to just the icon, maximize to near-fullscreen, or close
it entirely. Booster tools: DNS benchmarking with one-tap Private DNS
setup, a Do-Not-Disturb "Game Mode" that restores your prior settings when
you stop, a best-effort memory optimizer with automated background
purging, a graphics-profile config editor for games that support it, a
whole-screen night-vision display filter, a Wi-Fi performance lock,
refresh-rate info, a brightness lock, and per-game profile presets.
Settings includes a theme color picker and Terms & Conditions.

**What this app deliberately does NOT do:** it never reads, injects into,
or modifies another app's memory or running process. There is no crosshair
overlay, aim assist, wallhack/ESP, auto-clicker/macro bot, or paid-content
unlock feature, and there never will be — those would violate game terms
of service and app-store policy (and in the auto-clicker/anti-detection
case, are specifically designed to evade anti-cheat systems) regardless of
how they're framed, so they're out of scope on purpose.

## Floating window design

`FloatingWindowController.kt` is a pure, dependency-free state machine
(three modes: MINIMIZED, WINDOWED, MAXIMIZED) with 11 unit tests covering
the trickiest cases — e.g. maximizing then restoring returns to the exact
original position and size, resize requests below the minimum get clamped
rather than crashing, and dragging near a screen edge can't push the
window off-screen. `FloatingWindowService.kt` is the thin Android layer
that turns those decisions into real `WindowManager` calls — kept
separate on purpose so the logic could actually be verified instead of
just trusted by inspection.

## Audit fixes in this pass

While revising the overlay, I reviewed the rest of the codebase for real
correctness bugs rather than only adding new code on top:

- **Foreground service start bug**: `RamAutoPurgeService`, the floating
  window, and the Night Vision filter are all foreground services, but
  were being started with plain `startService()`. On Android 8+, that can
  throw `ForegroundServiceDidNotStartInTimeException` if the app
  backgrounds before the service calls `startForeground()`. Fixed by
  switching every call site to `ContextCompat.startForegroundService()`.
- **Coroutine leak risk**: the DNS benchmark button launched a raw,
  unscoped `CoroutineScope(Dispatchers.Main)` — if the user left the
  screen mid-benchmark, that coroutine would keep running and could crash
  trying to update a destroyed Activity's views. Fixed by switching to
  `lifecycleScope`, which cancels automatically when the Activity is
  destroyed.

## Honest status

- The pure-logic engines (`DnsOptimizer`, `NetworkQualityMonitor`,
  `BatteryDataProfileManager`, `GfxProfileManager.Preset`,
  `GameSessionStateMachine`, `ColorUtils`, `RamPurgeDecision`,
  `FloatingWindowController`) have no Android dependency and matching
  JUnit tests in `app/src/test/java/com/likas/boost/CoreLogicTest.kt`
  (32 tests total).
- I do not have Android Studio, an Android SDK, or a device/emulator in my
  own environment, so **I could not compile the actual .apk or run it
  myself.** I mirrored the same decision logic in plain Java, installed a
  JDK in my sandbox, and ran matching checks there — all passed (this is a
  logic check, not proof the Android app compiles).
- The "Memory Optimizer" is intentionally honest about Android's limits:
  no non-rooted app can force-free another app's RAM on modern Android.
  It clears its own cache and calls the public trim API — see the comment
  block at the top of `MemoryOptimizer.kt` for the full explanation.
- The "Ping Lock" (DNS) doesn't secretly intercept traffic — a non-root app
  can't force system DNS. It copies the recommended hostname and opens
  Android's real Private DNS setting for you to apply in two taps. See
  `DnsLockHelper.kt`.
- The "Wi-Fi Band Prioritization" doesn't force 5GHz/6GHz — that's not
  something third-party apps can control. It acquires a real
  `WifiManager.WifiLock` (`WIFI_MODE_FULL_HIGH_PERF`), which keeps the
  radio out of power-save mode, the actual common cause of Wi-Fi latency
  spikes on Android. See `WifiPerformanceLock.kt`.
- The "Refresh Rate Locker" can only request a high refresh mode for
  LIKAS's *own* windows (a real, documented API) — it can't force another
  app's refresh rate. It reports the device's real max refresh rate and
  deep-links to system Display settings for the actual system-wide
  control. See `RefreshRateManager.kt`.
- The "Auto Memory Purge" reacts to real memory-pressure signals
  (`ActivityManager.MemoryInfo`), not literal FPS telemetry — no
  third-party app can read another app's live frame rate without special
  system access. See the doc comment in `RamAutoPurgeService.kt`.
- The Night Vision filter is a plain semi-transparent overlay window; the
  brightening effect comes from Android's normal window alpha-compositing,
  not from reading or altering game pixels. See `NightVisionOverlayService.kt`.
- The "Graphics Profile" tool writes a config file into a folder you pick
  yourself (via Android's normal file picker). It only takes effect for
  games that read settings from an accessible config file — that varies
  per game and isn't something any app can guarantee or work around.
- The intro sound (`res/raw/intro_whoosh.wav`) is an originally synthesized
  tone, not a copyrighted sample — swap in your own file of the same name
  to change it.
- The GitHub Actions workflow below (`.github/workflows/build-apk.yml`) is
  what actually compiles the real APK, in the cloud, so you don't need
  Android Studio at all. You should treat the **first Actions run** as the
  real test — if something doesn't match on your account's default Gradle/
  AGP versions, the error will show directly in the Actions log and is
  usually a one-line version fix.
- The overlay window, VPN consent dialog, and live sensor readings are
  Android-runtime behavior I cannot verify outside a real device — they need
  you to test them after installing.

## What's in this zip

```
LikasBoost/
├── app/
│   ├── build.gradle
│   ├── src/main/AndroidManifest.xml
│   ├── src/main/java/com/likas/boost/   (Kotlin source)
│   ├── src/main/res/                    (layouts, strings, icon)
│   └── src/test/java/com/likas/boost/CoreLogicTest.kt
├── build.gradle
├── settings.gradle
├── gradle.properties
└── .github/workflows/build-apk.yml
```

## Step-by-step: phone-only, zero Android Studio, zero folder wrangling

GitHub's web upload doesn't auto-extract zips, so instead of fighting your
phone's file picker over folder structure, you upload **one zip file**
(`project-source.zip`) plus **one small text file**
(the workflow itself), and the cloud build unzips the rest for you
automatically as its first step.

### 1. Create the GitHub repo
1. Open the GitHub app (or github.com) and log in.
2. Tap **+ → New repository**.
3. Name it `LikasBoost` (or anything). Public or Private, either works.
   Don't add a README/gitignore.
4. Tap **Create repository**.

### 2. Add the workflow file (one file, typed path)
1. On the repo page, tap **Add file → Create new file**.
2. In the filename box, type exactly:
   `.github/workflows/build-apk.yml`
   (GitHub creates the `.github` and `workflows` folders for you
   automatically — you don't make folders yourself.)
3. Open `build-apk.yml` from this zip in a text editor, copy its full
   contents, and paste them into GitHub's editor box.
4. Scroll down, commit directly to `main`.

### 3. Upload the source zip (one file, no unzipping needed)
1. Tap **Add file → Upload files**.
2. Select `project-source.zip` from this download **as-is — do not unzip
   it first**. Just upload the zip file itself.
3. Commit directly to `main`.

That's it — two uploads total, no folder structure to manage on your phone.

### 3. Let GitHub Actions build the APK
1. Go to the **Actions** tab of your repo.
2. You should see a workflow run called **Build APK** already running
   (it triggers automatically on push to `main`). If it's not there, tap
   **Build APK** in the left list, then **Run workflow**.
3. Tap into the running job and watch it go: checkout → set up JDK → set up
   Android SDK → set up Gradle → run unit tests → build debug APK → upload
   artifact. This takes a few minutes.
4. If it fails, tap the red step to see the exact error — it's almost
   always a version mismatch (e.g. AGP vs Gradle vs SDK level), and the log
   tells you which line to bump in `app/build.gradle` or `build.gradle`.

### 4. Download the APK to your phone
1. Once the run finishes (green check), scroll to the bottom of that run's
   page to **Artifacts**.
2. Tap **LikasBoost-debug-apk** to download it — it'll download as a small
   zip containing the `.apk`.
3. Extract that zip (same as step 2) to get `app-debug.apk`.
4. Tap the `.apk` file in your file manager to install it. Android will
   warn about "installing from unknown sources" the first time — allow it
   for your file manager app in Settings, then tap Install again.

### 5. On first launch
- **Stats overlay**: tap "Start Stats Overlay" → Android will send you to a
  permission screen ("Display over other apps") → enable it for LikasBoost
  → go back and tap the button again.
- **Traffic priority**: tap "Start Traffic Priority" → Android shows the
  standard VPN consent dialog ("LikasBoost wants to set up a VPN connection
  that can monitor network traffic") → this is Android's normal, mandatory
  dialog for any app using `VpnService`, and it's here because the feature
  genuinely does route your own traffic locally through this tunnel to
  reorder it — tap OK to allow it.
- **DNS benchmark**: works immediately, no permission needed.

## If you'd rather not use GitHub Actions

Any Windows/Mac/Linux PC with Android Studio installed can also just open
this folder as a project and hit **Build → Build Bundle(s)/APK(s) → Build
APK(s)** — the project needs zero changes for that path.
